import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.security.SecureRandom;
import java.util.Random;
import java.sql.*;
import java.util.Collections;
import java.util.Date;
import java.text.SimpleDateFormat;
public class ProgramController {
    ArrayList<User> Users=new ArrayList<>();
    ArrayList<Card> starterPack=new ArrayList<>();
    ArrayList<Card> starterPack2=new ArrayList<>();
    int menu=0;
    int loginIndex=0;
    int otherPlayer=0;
    int n=0;
    private static long startTime=0;
    Connection c = null;
    Statement stmt = null;
    ArrayList<Card> gameCards=new ArrayList<>();
    boolean secondPlayerEntered=false;
    int s=0;
    String StartGame = "\\s*start\\s+game\\s*";
    String ShowCards = "\\s*show\\s+cards\\s*";
    String ShowGameHistory = "\\s*show\\s+games\\s+history\\s*";
    String Shop = "\\s*shop\\s*";
    String Profile = "\\s*profile\\s*";
    String Logout ="\\s*logout\\s*";
    String Back = "\\s*back\\s*";
    String Sort ="\\s*sort\\s*";
    String NextPage = "\\s*next\\s*";
    String PreviousPage = "\\s*previous\\s*";
    String PageNumber = "\\d+";
    String ShowShopCards = "\\s*show\\s+shop\\s+cards\\s*";
    String ShowUpgradeable = "\\s*show\\s+upgradeable\\s+cards\\s*";
    String Upgrade = "\\s*upgrade\\s+(?<code>\\d+)\\s*";
    String Buy = "\\s*buy\\s+(?<code>\\d+)\\s*";
    String multiPlayerMode = "\\s*multiplayer\\s+mode\\s*";
    String gamblingMode = "\\s*gambling\\s+mode\\s*";
    String showAfterUpgrade = "\\s*show\\s+after\\s+upgrade\\s*";
    Pattern chooseCard = Pattern.compile("-Select\\s+card\\s+(?<code>\\d)\\s+player\\s+(?<player>\\d+)\\s*");
    Pattern playCard = Pattern.compile("\\s*-Placing\\s+card\\s+(?<code>\\d)\\s+in\\s+block\\s+(?<location>\\d+)\\s*");
    Pattern choseChar = Pattern.compile("\\s*choose\\s+character\\s+(?<code>\\d)\\s*");
    ProgramController()
    {

    }
    public void run()
    {
        try{
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:test1.db");
            c.setAutoCommit(false);
            stmt = c.createStatement();

            ResultSet rs = stmt.executeQuery( "SELECT * FROM CARDS2;" );
            while (rs.next())
            {
                if (rs.getString("name").equals("shield") || rs.getString("name").equals("heal") || rs.getString("name").equals("buff") || rs.getString("name").equals("repair") || rs.getString("name").equals("round_dec") || rs.getString("name").equals("remover") || rs.getString("name").equals("debuffer") || rs.getString("name").equals("copy") || rs.getString("name").equals("hider") || rs.getString("name").equals("magnet"))
                    starterPack2.add(new Card(rs.getString("name"),rs.getInt("attack"),rs.getInt("duration"),rs.getInt("damage"),rs.getInt("uplevel"),rs.getInt("upcost"),rs.getInt("character")));
            }
            stmt.close();
            c.commit();
            c.close();
        } catch ( Exception e ) {
            System.err.println( e.getClass().getName() + ": " + e.getMessage() );
            System.exit(0);
        }
        try{
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:test1.db");
            c.setAutoCommit(false);
            stmt = c.createStatement();
//                String sql = "CREATE TABLE CARDS2 " +
//                        "(ID             INT     NOT NULL," +
//                        " NAME           TEXT    NOT NULL, " +
//                        " ATTACK         INT     NOT NULL, " +
//                        " DURATION       INT     NOT NULL, " +
//                        " DAMAGE          INT     NOT NULL, " +
//                        " UPLEVEL        INT     NOT NULL, " +
//                        " UPCOST         INT     NOT NULL)";
//                stmt.executeUpdate(sql);

//            String sql = "ALTER TABLE CARDS2 ADD COLUMN CHARACTER INTEGER;";
//            stmt.executeUpdate(sql);
//            c.commit();

            ResultSet rs = stmt.executeQuery( "SELECT * FROM CARDS2;" );
            while (rs.next())
            {
                if (rs.getInt("id")<10)
                    starterPack.add(new Card(rs.getString("name"),rs.getInt("attack"),rs.getInt("duration"),rs.getInt("damage"),rs.getInt("uplevel"),rs.getInt("upcost"),rs.getInt("character")));
            }
            stmt.close();
            c.commit();
            c.close();
        } catch ( Exception e ) {
            System.err.println( e.getClass().getName() + ": " + e.getMessage() );
            System.exit(0);
        }
        try{
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:test1.db");
            c.setAutoCommit(false);
            stmt = c.createStatement();
//                String sql = "CREATE TABLE CARDS2 " +
//                        "(ID             INT     NOT NULL," +
//                        " NAME           TEXT    NOT NULL, " +
//                        " ATTACK         INT     NOT NULL, " +
//                        " DURATION       INT     NOT NULL, " +
//                        " DAMAGE          INT     NOT NULL, " +
//                        " UPLEVEL        INT     NOT NULL, " +
//                        " UPCOST         INT     NOT NULL)";
//                stmt.executeUpdate(sql);


            ResultSet rs = stmt.executeQuery( "SELECT * FROM CARDS2;" );
            while (rs.next())
            {
                gameCards.add(new Card(rs.getString("name"),rs.getInt("attack"),rs.getInt("duration"),rs.getInt("damage"),rs.getInt("uplevel"),rs.getInt("upcost"),rs.getInt("character")));
            }
            stmt.close();
            c.commit();
            c.close();
        } catch ( Exception e ) {
            System.err.println( e.getClass().getName() + ": " + e.getMessage() );
            System.exit(0);
        }
        try{
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:test1.db");
            c.setAutoCommit(false);
            stmt = c.createStatement();
//                String sql = "CREATE TABLE CARDS2 " +
//                        "(ID             INT     NOT NULL," +
//                        " NAME           TEXT    NOT NULL, " +
//                        " ATTACK         INT     NOT NULL, " +
//                        " DURATION       INT     NOT NULL, " +
//                        " DAMAGE          INT     NOT NULL, " +
//                        " UPLEVEL        INT     NOT NULL, " +
//                        " UPCOST         INT     NOT NULL)";
//                stmt.executeUpdate(sql);


            ResultSet rs = stmt.executeQuery( "SELECT * FROM USERS;" );
            while (rs.next())
            {
                String s=rs.getString("cards");
                String[] a=s.split("\\s+");
                ArrayList<Card> b=new ArrayList<>();
                for (int i=0;i<gameCards.size();i++)
                {
                    for (int j=0;j<a.length;j++)
                    {
                        if (gameCards.get(i).getName().equals(a[j]))
                            b.add(gameCards.get(i));
                    }
                }
                Users.add(new User(rs.getString("username"),rs.getString("pass"),rs.getString("nickname"),rs.getString("email"),rs.getString("pra"),rs.getInt("prq"),b));
            }
            stmt.close();
            c.commit();
            c.close();
        } catch ( Exception e ) {
            System.err.println( e.getClass().getName() + ": " + e.getMessage() );
            System.exit(0);
        }
        Scanner sc=new Scanner(System.in);
        String input=sc.nextLine();
        while (!input.equals("end"))
        {
            gotoLoginMenu(getCommandStrMatcher(input,"go\\s+to\\s+login\\s+menu"));
            gotoProfileMenu(getCommandStrMatcher(input,"profile\\s+menu"));
            if (menu==0)
            {
                UserCreate(getCommandStrMatcher(input,"^user\\s+create\\s+-u\\s+(.*)\\s+-p\\s+(.*)\\s+(.*)\\s+-email\\s+(.*)\\s+-n\\s+(.*)$"),sc);
                UserCreateRandomPass(getCommandStrMatcher(input,"^user\\s+create\\s+-u\\s+(.*)\\s+-p\\s+random\\s+-email\\s+(.*)\\s+-n\\s+(.*)$"),sc);
            }
            if (menu==1)
            {
                login(getCommandStrMatcher(input,"user\\s+login\\s+-u\\s+(.*)\\s+-p\\s+(.*)"));
                ForgotPass(getCommandStrMatcher(input,"Forgot\\s+my\\s+password\\s+-u\\s+(.*)"),sc);
                logout(getCommandStrMatcher(input,"logout"));
            }
            if (menu==6)
            {
                ShowInformation(getCommandStrMatcher(input,"Show\\s+information"));
                ChangeUsername(getCommandStrMatcher(input,"Profile\\s+change\\s+-u\\s+(.*)"));
                ChangeNickname(getCommandStrMatcher(input,"Profile\\s+change\\s+-n\\s+(.*)"));
                ChangePassword(getCommandStrMatcher(input,"profile\\s+change\\s+password\\s+-o\\s+(.+)\\s+-n\\s+(.+)"),sc);
                ChangeEmail(getCommandStrMatcher(input,"profile\\s+change\\s+-e\\s+(.+)"));
            }
            AdminLogin(getCommandStrMatcher(input,"-login\\s+admin\\s+(.+)"));
            if (menu==10)
            {
                AddCard(getCommandStrMatcher(input,"add\\s+card"),sc);
                RemoveCard(getCommandStrMatcher(input,"remove\\s+card"),sc);
                EditCard(getCommandStrMatcher(input,"edit\\s+card"),sc);
                ShowPlayers(getCommandStrMatcher(input,"show\\s+players"));
                backInEdit(getCommandStrMatcher(input,"back"));
            }
            if (menu == 2) { // main menu
                if(getCommandStrMatcher(input , StartGame).matches()){
                    System.out.println("moved to the game mode menu");
                    menu = 3;
                } else if (getCommandStrMatcher(input , ShowCards).matches()) {
//                    System.out.println("Name    Attack    Defence    Duration    Player Damage    Level");
//                    for(Card card : Users.get(loginIndex).getCards()){
//                        if(!card.IsSpecail()){
//                            System.out.println(card.getName() + "    " + card.getAttack_defence() + "    " + card.getDuration() + "    " + card.getDuration() + "    " + card.getBuy_level());
//                        }
//                    }
//                    System.out.println("Special cards");
//                    for(Card card : Users.get(loginIndex).getCards()){
//                        if(card.IsSpecail()){
//                            System.out.println(card.getName());
//                        }
//                    }
                    try{
                        Class.forName("org.sqlite.JDBC");
                        c = DriverManager.getConnection("jdbc:sqlite:test1.db");
                        c.setAutoCommit(false);
                        stmt = c.createStatement();
                        ResultSet rs = stmt.executeQuery( "SELECT * FROM CARDS2;" );
                        while ( rs.next() ) {
                            boolean exist=false;
                            for (int i=0;i<Users.get(loginIndex).getCards().size();i++)
                            {
                                if (rs.getString("name").equals(Users.get(loginIndex).getCards().get(i).getName()))
                                    exist=true;
                            }
                            if (exist)
                            {
                                int Id=rs.getInt("id");
                                String Name = rs.getString("name");
                                int Attack= rs.getInt("attack");
                                int Duration= rs.getInt("duration");
                                int Damage= rs.getInt("damage");
                                int Uplevel= rs.getInt("uplevel");
                                int Upcost= rs.getInt("upcost");
                                int Character= rs.getInt("character");

                                System.out.println( "id = " + Id);
                                System.out.println( "name = " + Name);
                                System.out.println( "attack defence = " + Attack );
                                System.out.println( "duration = " + Duration );
                                System.out.println( "damage = " + Damage );
                                System.out.println( "upgrade level = " + Uplevel );
                                System.out.println( "upgrade cost = " + Upcost );
                                System.out.println( "character = " + Character);
                                System.out.println();
                            }
                        }
                        stmt.close();
                        c.commit();
                        c.close();
                    }catch ( Exception e ) {
                        System.err.println( e.getClass().getName() + ": " + e.getMessage() );
                        System.exit(0);
                    }
                } else if (getCommandStrMatcher(input , ShowGameHistory).matches()) {
                    System.out.println("moved to the previous games table menu");
                    menu = 7;
                } else if (getCommandStrMatcher(input , Shop).matches()) {
                    System.out.println("moved to the shop menu");
                    menu = 5;
                } else if (getCommandStrMatcher(input , Profile).matches()) {
                    System.out.println("moved to the profile menu");
                    menu = 6;
                } else if (getCommandStrMatcher(input , Logout).matches()) {
                    System.out.println("logged out successfully");
                    menu = 1;
                }
            } else if (menu == 3) { // choose game mode
                otherPlayerLogin(getCommandStrMatcher(input,"second\\s+player\\s+login\\s+-u\\s+(.*)\\s+-p\\s+(.*)"));
                if(getCommandStrMatcher(input , multiPlayerMode).matches()){
                    multiplayerGame(loginIndex,otherPlayer);
                } else if (getCommandStrMatcher(input , gamblingMode).matches()) {

                } else if (getCommandStrMatcher(input , Back).matches()) {
                    System.out.println("back to main menu");
                    menu = 2;
                }
            } else if (menu == 4) { // game menu

            } else if (menu == 5) { // shop menu
                if(getCommandStrMatcher(input , ShowShopCards).matches()){
                    menu = 8;
                    System.out.println("buyable cards :");
                    for (Card card : Users.get(loginIndex).getBuyAble(gameCards))
                    {
                        System.out.println("name: "+card.getName());
                        System.out.println("attack/defence: "+card.getAttack_defence());
                        System.out.println("duration: "+card.getDuration());
                        System.out.println("player damage: "+card.getPlayer_damage());
                        System.out.println();
                    }
//                    for (int i=0;i<gameCards.size();i++)
//                    {
//                        for (int j=0;j<Users.get(loginIndex).getCards().size();j++)
//                        {
//                            if (Users.get(loginIndex).getCards().get(j).getName().equals(gameCards.get(i).getName()))
//                                gameCards.get(i).buyAble=false;
//                        }
//                    }
//                    for (int i=0;i<gameCards.size();i++)
//                    {
//                        if (gameCards.get(i).buyAble)
//                        {
//                            System.out.println("name: "+gameCards.get(i).getName());
//                            System.out.println("attack/defence: "+gameCards.get(i).getAttack_defence());
//                            System.out.println("duration: "+gameCards.get(i).getDuration());
//                            System.out.println("player damage: "+gameCards.get(i).getPlayer_damage());
//                            System.out.println();
//                        }
//                    }
                } else if (getCommandStrMatcher(input , ShowUpgradeable).matches()) {
                    menu = 9;
                    System.out.println("upgradeable cards");
                    for (int i=0;i<Users.get(loginIndex).getCards().size();i++)
                    {
                        if (Users.get(loginIndex).getCards().get(i).isUpgradeable())
                        {
                            System.out.println((i+1)+". name: "+gameCards.get(i).getName());
                            System.out.println("attack/defence: "+gameCards.get(i).getAttack_defence());
                            System.out.println("duration: "+gameCards.get(i).getDuration());
                            System.out.println("player damage: "+gameCards.get(i).getPlayer_damage());
                            System.out.println();
                        }
                    }
                } else if (getCommandStrMatcher(input , Back).matches()) {
                    menu = 2;
                    System.out.println("moved to the main menu");
                }
            } else if (menu == 6) { //profile menue

            } else if (menu == 7) { //previos games menu
                if(getCommandStrMatcher(input , Sort).matches()){
                    try{
                        Class.forName("org.sqlite.JDBC");
                        c = DriverManager.getConnection("jdbc:sqlite:test1.db");
                        c.setAutoCommit(false);
                        stmt = c.createStatement();

                        ResultSet rs = stmt.executeQuery( "SELECT * FROM HISTORY;" );
                        while ( rs.next() ) {
                            String date=rs.getString("date");
                            String players=rs.getString("players");
                            String winner=rs.getString("winner");

                            System.out.println("date: "+date);
                            System.out.println("players: "+players);
                            System.out.println("winner: "+winner);
                            System.out.println();
                        }
                        stmt.close();
                        c.commit();
                        c.close();
                    } catch ( Exception e ) {
                        System.err.println( e.getClass().getName() + ": " + e.getMessage() );
                        System.exit(0);
                    }
                } else if (getCommandStrMatcher(input , NextPage).matches()) {

                } else if (getCommandStrMatcher(input , PreviousPage).matches()) {

                } else if (getCommandStrMatcher(input , PageNumber).matches()) {

                } else if (getCommandStrMatcher(input , Back).matches()) {
                    menu = 2;
                    otherPlayer=0;
                    System.out.println("moved to the main menu");
                }
            } else if (menu == 8) { // shop menu buy
                if(getCommandStrMatcher(input , Buy).matches()){
                    int i = 0;
                    for(Card card : Users.get(loginIndex).getBuyAble(gameCards)){
                        i++;
                        if(card.IsSpecail()){
                            System.out.println(i + "    " + card.getName() + "    " + card.getPrice());
                        } else {
                            System.out.println(i + "    " + card.getName() + "    " + card.getPrice() + "    " + card.getAttack_defence() + "    " + card.getDuration() + "    " + card.getPlayer_damage());
                        }
                    }

                    Matcher matcher = getCommandStrMatcher(input , Buy);
                    matcher.matches();
                    int buy_code = Integer.parseInt(matcher.group("code"))-1;

                    if(Users.get(loginIndex).getBuyAble(gameCards).get(buy_code).getPrice() <= Users.get(loginIndex).getCoins() && Users.get(loginIndex).getBuyAble(gameCards).get(buy_code).getPrice() < Users.get(loginIndex).getLevel()){
                        try{
                            Class.forName("org.sqlite.JDBC");
                            c = DriverManager.getConnection("jdbc:sqlite:test1.db");
                            c.setAutoCommit(false);
                            stmt = c.createStatement();
                            ResultSet rs = stmt.executeQuery( "SELECT * FROM USERS;" );
                            while ( rs.next() ) {
                                if (rs.getString("username").equals(Users.get(loginIndex).Username))
                                {
                                    stmt = c.createStatement();
                                    String sql = "UPDATE USERS set CARDS = '"+(rs.getString("cards")+" "+Users.get(loginIndex).getBuyAble(gameCards).get(buy_code).getName())+"' where USERNAME='"+Users.get(loginIndex).Username+"';";
                                    stmt.executeUpdate(sql);
                                    c.commit();
                                }
                            }
                            stmt.close();
                            c.commit();
                            c.close();
                        } catch ( Exception e ) {
                            System.err.println( e.getClass().getName() + ": " + e.getMessage() );
                            System.exit(0);
                        }
                        System.out.println("card purchased successfully");

                        ArrayList<Card> g=Users.get(loginIndex).getCards();
                        g.add(Users.get(loginIndex).getBuyAble(gameCards).get(buy_code));
                        Users.get(loginIndex).setCards(g);

                        Users.get(loginIndex).setCoins(Users.get(loginIndex).getCoins() - Users.get(loginIndex).getBuyAble(gameCards).get(buy_code).getPrice());
                    } else {
                        System.out.println("not enough coins for purchasing the card");
                    }
                } else if (getCommandStrMatcher(input , Back).matches()) {
                    menu = 5;
                }
            } else if (menu == 9) { // shop menu upgrade
                if (getCommandStrMatcher(input, showAfterUpgrade).matches()) {
                    int i = 0;
                    for (Card card : Users.get(loginIndex).getUpgradeAble()) {
                        i++;
                        if (card.IsSpecail()) {
                            if (card.code() == 1) {
                                System.out.println(i + "    " + "Heal" + "    " + Math.ceil(20 * Math.pow(1.2, card.getLevel())));
                            } else if (card.code() == 2) {
                                System.out.println(i + "    " + "Buff" + "    " + Math.ceil(10 * Math.pow(1.2, card.getLevel())));
                            } else if (card.code() == 6) {
                                System.out.println(i + "    " + "Enemy debuff" + "    " + Math.ceil(10 * Math.pow(1.2, card.getLevel())));
                            }
                            System.out.println(i + "    " + card.getName() + "    " + card.getUpgradePrice());
                        } else {
                            System.out.println(i + "    " + card.getName() + "    " + card.getUpgradePrice() + "    " + card.getAttack_defence() * 1.2 + "    " + card.getPlayer_damage() * 1.2);
                        }
                    }
                } else if (getCommandStrMatcher(input , Upgrade).matches()) {

                    Matcher matcher = getCommandStrMatcher(input, Upgrade);
                    matcher.matches();
                    int upgrade_code = Integer.parseInt(matcher.group("code"));

                    if (Users.get(loginIndex).getUpgradeAble().get(upgrade_code).getUpgradePrice() <= Users.get(loginIndex).getCoins()) {
                        System.out.println("card upgraded successfully");
                        Users.get(loginIndex).getUpgradeAble().get(upgrade_code).setLevel(Users.get(loginIndex).getUpgradeAble().get(upgrade_code).getLevel() + 1);

                    } else {
                        System.out.println("not enough coins for upgrading the card");
                    }

                } else if (getCommandStrMatcher(input, Back).matches()) {
                    menu = 5;
                }
            }

            input= sc.nextLine();

        }
    }
    private Matcher getCommandStrMatcher(String input, String regex)
    {
        Pattern pattern=Pattern.compile(regex);
        Matcher matcher=pattern.matcher(input);
        return matcher;
    }
    public void UserCreate (Matcher matcher,Scanner sc)
    {
        if (matcher.matches())
        {
            String username=matcher.group(1).trim();
            String password=matcher.group(2).trim();
            String passConfirm=matcher.group(3).trim();
            String email=matcher.group(4).trim();
            String nickname=matcher.group(5).trim();
            for(int i=1; i<6; i++){
                if (matcher.group(i).trim().equals("")){
                    System.out.println("field is empty");
                    return;
                }
            }
            if (getCommandStrMatcher(username,"(^[A-Za-z0-9_]$)").matches())
            {
                System.out.println("username is invalid");
                return;
            }
            for (int i=0;i<Users.size();i++)
            {
                if (username.equals(Users.get(i).Username))
                {
                    System.out.println("username exist");
                    return;
                }
            }
            if (!getCommandStrMatcher(password,"^(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9]).{8,}$").matches())
            {
                System.out.println("password is weak");
                return;
            }
            if (!getCommandStrMatcher(email,"^(.+)@(.+)\\.com$").matches())
            {
                System.out.println("invalid email");
                return;
            }

            System.out.println("User created successfully. Please choose a security question : \n" +
                    "• 1-What is your father’s name ? \n" +
                    "• 2-What is your favourite color ? \n" +
                    "• 3-What was the name of your first pet? \n");
            String input=sc.nextLine();
            while(!getCommandStrMatcher(input,"question\\s+pick\\s+-q\\s+(.*)\\s+-a\\s+(.*)\\s+-c\\s+(.*)").matches())
            {
                System.out.println("please try again");
                input=sc.nextLine();
            }
            QuestionAnswer(getCommandStrMatcher(input,"question\\s+pick\\s+-q\\s+(.*)\\s+-a\\s+(.*)\\s+-c\\s+(.*)"),username,password,nickname,email,sc);
        }
    }
    public void QuestionAnswer (Matcher matcher, String username, String pass, String nickname, String email,Scanner sc)
    {
        int PRQ=0;
        String PRA="";
        boolean ifAnswered=false;
        while (!ifAnswered)
        {
            if (matcher.matches())
            {
                String QNum=matcher.group(1).trim();
                String ans=matcher.group(2).trim();
                String ansConfirm=matcher.group(3).trim();

                if (Integer.parseInt(QNum)!=1 && Integer.parseInt(QNum)!=2 && Integer.parseInt(QNum)!=3)
                {
                    System.out.println("question number is invalid");
                    String input=sc.nextLine();
                    matcher=getCommandStrMatcher(input,"question\\s+pick\\s+-q\\s+(.*)\\s+-a\\s+(.*)\\s+-c\\s+(.*)");
                }
                if (!ans.equals(ansConfirm))
                {
                    System.out.println("please confirm yor answer again");
                    String input=sc.nextLine();
                    matcher=getCommandStrMatcher(input,"question\\s+pick\\s+-q\\s+(.*)\\s+-a\\s+(.*)\\s+-c\\s+(.*)");
                }
                if (ans.equals(ansConfirm) && (Integer.parseInt(QNum)==1 || Integer.parseInt(QNum)==2 || Integer.parseInt(QNum)==3))
                {
                    PRA=ans;
                    PRQ=Integer.parseInt(QNum);
                    ifAnswered=true;
                }
            }
        }
        captcha(sc,0);
        Users.add(new User(username,pass,nickname,email,PRA,PRQ,starterPack));
        try{
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:test1.db");
            c.setAutoCommit(false);
            stmt = c.createStatement();
//                String sql = "CREATE TABLE USERS " +
//                        "(USERNAME       TEXT    NOT NULL," +
//                        " PASS           TEXT    NOT NULL, " +
//                        " NICKNAME       TEXT    NOT NULL, " +
//                        " EMAIL          TEXT    NOT NULL, " +
//                        " PRA            TEXT    NOT NULL, " +
//                        " PRQ            INT     NOT NULL, " +
//                        " CARDS          TEXT    NOT NULL)";
//                stmt.executeUpdate(sql);

//            String sql = "ALTER TABLE USERS ADD COLUMN LEVEL INTEGER;";
//            stmt.executeUpdate(sql);
//            c.commit();
//
//            String sql3 = "ALTER TABLE USERS ADD COLUMN COIN INTEGER;";
//            stmt.executeUpdate(sql3);
//            c.commit();

//            stmt = c.createStatement();
//            String sql4 = "DELETE from USERS where USERNAME='yashar';";
//            stmt.executeUpdate(sql4);
//            c.commit();

            String cards="";
            for (int i=0;i<starterPack.size();i++)
            {
                cards=cards+" "+starterPack.get(i).getName();
            }
            String cards2="";
            for (int i=0;i<starterPack.size();i++)
            {
                cards2=cards2+" "+starterPack2.get(i).getName();
            }

            if (!username.equals("mohammad"))
            {
                String sql2 = "INSERT INTO USERS (USERNAME,PASS,NICKNAME,EMAIL,PRA,PRQ,CARDS,LEVEL,COIN) " +
                        "VALUES ('"+username+"', '"+pass+"', '"+nickname+"', '"+email+"', '"+PRA+"', "+PRQ+", '"+cards+"', "+1+", "+0+");";
                stmt.executeUpdate(sql2);
            }

            if (username.equals("mohammad"))
            {
                String sql2 = "INSERT INTO USERS (USERNAME,PASS,NICKNAME,EMAIL,PRA,PRQ,CARDS,LEVEL,COIN) " +
                        "VALUES ('"+username+"', '"+pass+"', '"+nickname+"', '"+email+"', '"+PRA+"', "+PRQ+", '"+cards2+"', "+1+", "+0+");";
                stmt.executeUpdate(sql2);
            }

            ResultSet rs = stmt.executeQuery( "SELECT * FROM USERS;" );
            while ( rs.next() ) {
                String Id=rs.getString("username");
                String Name = rs.getString("pass");
                String Attack= rs.getString("nickname");
                String Duration= rs.getString("email");
                String Damage= rs.getString("pra");
                int Uplevel= rs.getInt("prq");
                String Upcost= rs.getString("cards");
                int level=rs.getInt("level");
                int coin=rs.getInt("coin");

                System.out.println( "username = " + Id);
                System.out.println( "password = " + Name);
                System.out.println( "nickname = " + Attack );
                System.out.println( "email = " + Duration );
                System.out.println( "answer = " + Damage );
                System.out.println( "question = " + Uplevel );
                System.out.println( "cards = " + Upcost );
                System.out.println( "level = " + level );
                System.out.println( "coin = " + coin );
                System.out.println();
            }
            stmt.close();
            c.commit();
            c.close();
        } catch ( Exception e ) {
            System.err.println( e.getClass().getName() + ": " + e.getMessage() );
            System.exit(0);
        }
        menu=1;
    }
    public void UserCreateRandomPass (Matcher matcher, Scanner sc)
    {
        if (matcher.matches())
        {
            String username=matcher.group(1).trim();
            String email=matcher.group(2).trim();
            String nickname=matcher.group(3).trim();
            for(int i=1; i<4; i++){
                if (matcher.group(i).trim().equals("")){
                    System.out.println("field is empty");
                    return;
                }
            }
            if (getCommandStrMatcher(username,"(^[A-Za-z0-9_]$)").matches())
            {
                System.out.println("username is invalid");
                return;
            }
            for (int i=0;i<Users.size();i++)
            {
                if (username.equals(Users.get(i).Username))
                {
                    System.out.println("username exist");
                    return;
                }
            }
            if (!getCommandStrMatcher(email,"^(.+)@(.+)\\.com$").matches())
            {
                System.out.println("invalid email");
                return;
            }
            String pass=generateRandomPassword();
            System.out.println("Your random password: "+pass);
            System.out.println("Please enter your password :");
            boolean isConfirmed=false;
            while (!isConfirmed)
            {
                String input=sc.nextLine();
                if (input.equals(pass))
                {
                    isConfirmed=true;
                }
                if (!input.equals(pass))
                {
                    System.out.println("please confirm your password again:");
                }
            }
            System.out.println("User created successfully. Please choose a security question : \n" +
                    "• 1-What is your father’s name ? \n" +
                    "• 2-What is your favourite color ? \n" +
                    "• 3-What was the name of your first pet? \n");
            String input=sc.nextLine();
            while(!getCommandStrMatcher(input,"question\\s+pick\\s+-q\\s+(.*)\\s+-a\\s+(.*)\\s+-c\\s+(.*)").matches())
            {
                System.out.println("please try again");
                input=sc.nextLine();
            }
            QuestionAnswer(getCommandStrMatcher(input,"question\\s+pick\\s+-q\\s+(.*)\\s+-a\\s+(.*)\\s+-c\\s+(.*)"),username,pass,nickname,email,sc);
        }
    }
    public static String generateRandomPassword() {
        String uppercaseLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String lowercaseLetters = "abcdefghijklmnopqrstuvwxyz";
        String numbers = "0123456789";
        String specialCharacters = "!@#$%^&*()_+";
        StringBuilder password = new StringBuilder();
        SecureRandom random = new SecureRandom();
        password.append(uppercaseLetters.charAt(random.nextInt(uppercaseLetters.length())));

        password.append(lowercaseLetters.charAt(random.nextInt(lowercaseLetters.length())));

        password.append(numbers.charAt(random.nextInt(numbers.length())));

        password.append(specialCharacters.charAt(random.nextInt(specialCharacters.length())));

        for (int i = 4; i < 8; i++) {
            String allCharacters = uppercaseLetters + lowercaseLetters + numbers + specialCharacters;
            password.append(allCharacters.charAt(random.nextInt(allCharacters.length())));
        }

        String shuffledPassword = shuffleString(password.toString());

        return shuffledPassword;
    }

    public static String shuffleString(String input) {
        char[] characters = input.toCharArray();
        SecureRandom random = new SecureRandom();
        for (int i = characters.length - 1; i > 0; i--) {
            int index = random.nextInt(i + 1);
            char temp = characters[index];
            characters[index] = characters[i];
            characters[i] = temp;
        }
        return new String(characters);
    }
    public void captcha(Scanner sc, int a)
    {
        boolean isHuman=false;
        while(!isHuman)
        {
            String[][] numbers = {{
                    "  /  \\  ", // 0
                    "  / |  ", // 1
                    "  |_  )  ", // 2
                    " |__ / ", // 3
                    " | | |  ", // 4
                    "  | __| ", // 5
                    "   / /  ", // 6
                    "  |__  | ", // 7
                    " ( _ ) ", // 8
                    "  / _ \\ ", // 9
            }, {
                    " | () | ", // 0
                    "  | |  ", // 1
                    "   / /   ", // 2
                    "  |_ \\ ", // 3
                    " |_  _| ", // 4
                    "  |__ \\ ", // 5
                    "  / _ \\ ", // 6
                    "    / /  ", // 7
                    " / _ \\ ", // 8
                    "  \\_. / ", //9
            },{
                    "  \\__/  ", // 0
                    "  |_|  ", // 1
                    "  /___|  ", // 2
                    " |___/ ", // 3
                    "   |_|  ", // 4
                    "  |___/ ", // 5
                    "  \\___/ ", // 6
                    "   /_/   ", // 7
                    " \\___/ ", // 8
                    "   /_/  ", //9
            }};
            Random random = new Random();
            int numDigits = random.nextInt(3) + 5; // Generate a random number of digits between 5 and 7
            int[] nums=new int[numDigits];
            for (int i = 0; i < numDigits; i++)
            {
                nums[i]=random.nextInt(10);
            }
            for (int j=0;j<3;j++)
            {
                for (int i = 0; i < numDigits; i++) {
                    System.out.print(numbers[j][nums[i]]);
                    System.out.print(" "); // Add some space between each digit
                }
                System.out.println();
            }
            System.out.println();
            System.out.println("please type the digits above:");
            String captcha="";
            for (int i=0;i<numDigits;i++)
            {
                if (nums[i]==0)
                    captcha+="0";
                if (nums[i]==1)
                    captcha+="1";
                if (nums[i]==2)
                    captcha+="2";
                if (nums[i]==3)
                    captcha+="3";
                if (nums[i]==4)
                    captcha+="4";
                if (nums[i]==5)
                    captcha+="5";
                if (nums[i]==6)
                    captcha+="6";
                if (nums[i]==7)
                    captcha+="7";
                if (nums[i]==8)
                    captcha+="8";
                if (nums[i]==9)
                    captcha+="9";
            }
            String input=sc.nextLine();
            if (input.equals(captcha))
            {
                if (a==0)
                    System.out.println("that's right. you signed up successfully");
                if (a==1)
                    System.out.println("that's right. your password changed successfully");
                isHuman=true;
            }
            if (!input.equals(captcha))
            {
                System.out.println("please try again");
            }
        }
    }
    public void login (Matcher matcher)
    {
        if (matcher.matches())
        {
            long endTime=System.nanoTime();
            if (((endTime-startTime)/1000000000)<(n*5))
            {
                System.out.println("Try again in "+((n*5)-((endTime-startTime)/1000000000))+" seconds");
                return;
            }
            String username=matcher.group(1);
            String password=matcher.group(2);
            boolean exist=false;
            for (int i=0;i<Users.size();i++)
            {
                if (username.equals(Users.get(i).Username))
                {
                    exist=true;
                    loginIndex=i;
                }
            }
            if (!exist)
            {
                System.out.println("Username doesn’t exist!");
                loginIndex=0;
                return;
            }
            if (!Users.get(loginIndex).Password.equals(password))
            {
                System.out.println("Password and Username don’t match!");
                startTime = System.nanoTime();
                loginIndex=0;
                n++;
                return;
            }
            System.out.println("user logged in successfully!");
            menu=2;

//            try{
//                Class.forName("org.sqlite.JDBC");
//                c = DriverManager.getConnection("jdbc:sqlite:test1.db");
//                c.setAutoCommit(false);
//                stmt = c.createStatement();
//                ArrayList<Card> b=Users.get(loginIndex).getCards();
//                ResultSet rs = stmt.executeQuery( "SELECT * FROM USERS;" );
//                int p=0;
//                while ( rs.next() ) {
//                    if (p==loginIndex)
//                    {
//                        String s=rs.getString("cards");
//                        String[] a=s.split("\\s+");
//                        for (int i=0;i<gameCards.size();i++)
//                        {
//                            for (int j=0;j<a.length;j++)
//                            {
//                                if (a[j].equals(gameCards.get(i).getName()))
//                                    b.add(gameCards.get(i));
//                            }
//                        }
//                    }
//                    p++;
//                }
//                Users.get(loginIndex).setCards(b);
//                stmt.close();
//                c.commit();
//                c.close();
//            } catch ( Exception e ) {
//                System.err.println( e.getClass().getName() + ": " + e.getMessage() );
//                System.exit(0);
//            }
            n=0;
        }
    }
    public void ForgotPass (Matcher matcher, Scanner sc)
    {
        if (matcher.matches())
        {
            int userIndex=0;
            String username=matcher.group(1);
            boolean exist=false;
            for (int i=0;i<Users.size();i++)
            {
                if (username.equals(Users.get(i).Username))
                {
                    exist=true;
                    userIndex=i;
                }
            }
            if (!exist)
            {
                System.out.println("username not found");
                return;
            }
            Users.get(userIndex).ask();
            String ans=sc.nextLine();
            if (!ans.equals(Users.get(userIndex).PRA))
            {
                System.out.println("the answer is not right please try again!");
                return;
            }
            System.out.println("the answer was right, your password is:");
            System.out.println(Users.get(userIndex).Password);
        }
    }
    public void logout (Matcher matcher)
    {
        if (matcher.matches())
        {
            loginIndex=0;
            menu=0;
        }
    }
    public void gotoProfileMenu (Matcher matcher)
    {
        if (matcher.matches())
        {
            menu=6;
        }
    }
    public void ShowInformation (Matcher matcher)
    {
        if (matcher.matches())
        {
            System.out.println("username: "+Users.get(loginIndex).Username);
            System.out.println("password: "+Users.get(loginIndex).Password);
            System.out.println("email: "+Users.get(loginIndex).Email);
            System.out.println("nickname: "+Users.get(loginIndex).Nickname);
        }
    }
    public void ChangeUsername (Matcher matcher)
    {
        if (matcher.matches())
        {
            String username=matcher.group(1);
            for (int i=0;i<Users.size();i++)
            {
                if (username.equals(Users.get(i).Username))
                {
                    System.out.println("this username already exists");
                    return;
                }
            }
            Users.get(loginIndex).Username=username;
            System.out.println("username changed successfully");
        }
    }
    public void ChangeNickname (Matcher matcher)
    {
        if (matcher.matches())
        {
            String nickname=matcher.group(1);
            for (int i=0;i<Users.size();i++)
            {
                if (nickname.equals(Users.get(i).Nickname))
                {
                    System.out.println("this nickname already exists");
                    return;
                }
            }
            System.out.println("nickname changed successfully");
            Users.get(loginIndex).Nickname=nickname;
        }
    }
    public void ChangePassword (Matcher matcher, Scanner sc)
    {
        if (matcher.matches())
        {
            String oldPass=matcher.group(1);
            String newPass=matcher.group(2);
            if (!oldPass.equals(Users.get(loginIndex).Password))
            {
                System.out.println("Current password is incorrect!");
                return;
            }
            if (!getCommandStrMatcher(oldPass,"^(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9]).{8,}$").matches())
            {
                System.out.println("Please enter your new password again");
                return;
            }
            if (oldPass.equals(newPass))
            {
                System.out.println("Please enter a new password!");
                return;
            }
            captcha(sc,1);
            Users.get(loginIndex).Password=newPass;
        }
    }
    public void ChangeEmail (Matcher matcher)
    {
        if (matcher.matches())
        {
            String email=matcher.group(1);
            if (Users.get(loginIndex).Email.equals(email))
            {
                System.out.println("please enter a new email!");
                return;
            }
            if (!getCommandStrMatcher(email,"^(.+)@(.+)\\.com$").matches())
            {
                System.out.println("email is incorrect");
                return;
            }
            Users.get(loginIndex).Email=email;
            System.out.println("your email changed successfully");
        }
    }
    public void AdminLogin (Matcher matcher)
    {
        if (matcher.matches())
        {
            menu=10;
            if (!matcher.group(1).equals("pass"))
                System.out.println("pass is not correct!");
            if (matcher.group(1).equals("pass"))
                System.out.println("admin logged in successfully");
        }
    }
    public void AddCard (Matcher matcher,Scanner sc)
    {
        if (matcher.matches())
        {
            System.out.print("name: ");
            String name= sc.nextLine();

            System.out.print("card attack defence: ");
            int attack_defence= sc.nextInt();

            System.out.print("duration: ");
            int duration= sc.nextInt();

            System.out.print("player damage: ");
            int player_damage= sc.nextInt();

            System.out.print("upgrade level: ");
            int upgrade_level= sc.nextInt();

            System.out.print("upgrade cost: ");
            int upgrade_cost= sc.nextInt();

            System.out.print("character: ");
            int character= sc.nextInt();
            System.out.println();

            gameCards.add(new Card(name,attack_defence,duration,player_damage,upgrade_level,upgrade_cost,character));
            try{
                Class.forName("org.sqlite.JDBC");
                c = DriverManager.getConnection("jdbc:sqlite:test1.db");
                c.setAutoCommit(false);
                stmt = c.createStatement();
                ResultSet rs = stmt.executeQuery( "SELECT * FROM CARDS2;" );
                while ( rs.next() ) {
                    if (name.equals(rs.getString("name")))
                    {
                        System.out.println("this name already exists");
                        return;
                    }
                }
                stmt.close();
                c.commit();
                c.close();
            }catch ( Exception e ) {
                System.err.println( e.getClass().getName() + ": " + e.getMessage() );
                System.exit(0);
            }
            try{
                Class.forName("org.sqlite.JDBC");
                c = DriverManager.getConnection("jdbc:sqlite:test1.db");
                c.setAutoCommit(false);
                stmt = c.createStatement();
//                String sql = "CREATE TABLE CARDS2 " +
//                        "(ID             INT     NOT NULL," +
//                        " NAME           TEXT    NOT NULL, " +
//                        " ATTACK         INT     NOT NULL, " +
//                        " DURATION       INT     NOT NULL, " +
//                        " DAMAGE          INT     NOT NULL, " +
//                        " UPLEVEL        INT     NOT NULL, " +
//                        " UPCOST         INT     NOT NULL)";
//                stmt.executeUpdate(sql);

                ResultSet rs = stmt.executeQuery( "SELECT * FROM CARDS2;" );
                while (rs.next())
                {
                    if (s<rs.getInt("id"))
                        s=rs.getInt("id");
                }
                String sql2 = "INSERT INTO CARDS2 (ID,NAME,ATTACK,DURATION,DAMAGE,UPLEVEL,UPCOST,CHARACTER) " +
                        "VALUES ("+(s+1)+", '"+name+"', "+attack_defence+", "+duration+", "+player_damage+", "+upgrade_level+", "+upgrade_cost+", "+character+" );";

                stmt.executeUpdate(sql2);
                ResultSet rs2 = stmt.executeQuery( "SELECT * FROM CARDS2;" );
                while ( rs2.next() ) {
                    int Id=rs.getInt("id");
                    String Name = rs.getString("name");
                    int Attack= rs.getInt("attack");
                    int Duration= rs.getInt("duration");
                    int Damage= rs.getInt("damage");
                    int Uplevel= rs.getInt("uplevel");
                    int Upcost= rs.getInt("upcost");
                    int Character= rs.getInt("character");

                    System.out.println( "id = " + Id);
                    System.out.println( "name = " + Name);
                    System.out.println( "attack defence = " + Attack );
                    System.out.println( "duration = " + Duration );
                    System.out.println( "damage = " + Damage );
                    System.out.println( "upgrade level = " + Uplevel );
                    System.out.println( "upgrade cost = " + Upcost );
                    System.out.println( "character = " + Character);
                    System.out.println();
                }
                stmt.close();
                c.commit();
                c.close();
            } catch ( Exception e ) {
                System.err.println( e.getClass().getName() + ": " + e.getMessage() );
                System.exit(0);
            }
        }
    }
    public void RemoveCard (Matcher matcher,Scanner sc)
    {
        if (matcher.matches())
        {
            try{
                Class.forName("org.sqlite.JDBC");
                c = DriverManager.getConnection("jdbc:sqlite:test1.db");
                c.setAutoCommit(false);
                stmt = c.createStatement();
                ResultSet rs = stmt.executeQuery( "SELECT * FROM CARDS2;" );
                while ( rs.next() ) {
                    int Id=rs.getInt("id");
                    String Name = rs.getString("name");
                    int Attack= rs.getInt("attack");
                    int Duration= rs.getInt("duration");
                    int Damage= rs.getInt("damage");
                    int Uplevel= rs.getInt("uplevel");
                    int Upcost= rs.getInt("upcost");
                    int Character= rs.getInt("character");

                    System.out.println( "id = " + Id);
                    System.out.println( "name = " + Name);
                    System.out.println( "attack defence = " + Attack );
                    System.out.println( "duration = " + Duration );
                    System.out.println( "damage = " + Damage );
                    System.out.println( "upgrade level = " + Uplevel );
                    System.out.println( "upgrade cost = " + Upcost );
                    System.out.println( "character = " + Character);
                    System.out.println();
                }
                stmt.close();
                c.commit();
                c.close();
            }catch ( Exception e ) {
                System.err.println( e.getClass().getName() + ": " + e.getMessage() );
                System.exit(0);
            }
            int cardId=sc.nextInt();
            System.out.println("are you sure you want to delete this card?( y/n)");
            String confirm=sc.next();
            if (getCommandStrMatcher(confirm,"no").matches())
                return;
            if (getCommandStrMatcher(confirm,"yes").matches())
            {
                try{

                    Class.forName("org.sqlite.JDBC");
                    c = DriverManager.getConnection("jdbc:sqlite:test1.db");
                    c.setAutoCommit(false);

                    stmt = c.createStatement();
                    String sql = "DELETE from CARDS2 where ID="+cardId+";";
                    stmt.executeUpdate(sql);
                    c.commit();

                    ResultSet rs = stmt.executeQuery( "SELECT * FROM CARDS2;" );
                    while ( rs.next() ) {
                        int Id=rs.getInt("id");
                        String Name = rs.getString("name");
                        int Attack= rs.getInt("attack");
                        int Duration= rs.getInt("duration");
                        int Damage= rs.getInt("damage");
                        int Uplevel= rs.getInt("uplevel");
                        int Upcost= rs.getInt("upcost");
                        int Character= rs.getInt("character");

                        System.out.println( "id = " + Id);
                        System.out.println( "name = " + Name);
                        System.out.println( "attack defence = " + Attack );
                        System.out.println( "duration = " + Duration );
                        System.out.println( "damage = " + Damage );
                        System.out.println( "upgrade level = " + Uplevel );
                        System.out.println( "upgrade cost = " + Upcost );
                        System.out.println( "character = " + Character);
                        System.out.println();
                    }
                    stmt.close();
                    c.commit();
                    c.close();
                }catch ( Exception e ) {
                    System.err.println( e.getClass().getName() + ": " + e.getMessage() );
                    System.exit(0);
                }
            }

        }
    }
    public void EditCard (Matcher matcher,Scanner sc)
    {
        if (matcher.matches())
        {
            try{
                Class.forName("org.sqlite.JDBC");
                c = DriverManager.getConnection("jdbc:sqlite:test1.db");
                c.setAutoCommit(false);
                stmt = c.createStatement();
                ResultSet rs = stmt.executeQuery( "SELECT * FROM CARDS2;" );
                while ( rs.next() ) {
                    int Id=rs.getInt("id");
                    String Name = rs.getString("name");
                    int Attack= rs.getInt("attack");
                    int Duration= rs.getInt("duration");
                    int Damage= rs.getInt("damage");
                    int Uplevel= rs.getInt("uplevel");
                    int Upcost= rs.getInt("upcost");
                    int Character= rs.getInt("character");

                    System.out.println( "id = " + Id);
                    System.out.println( "1. name = " + Name);
                    System.out.println( "2. attack defence = " + Attack );
                    System.out.println( "3. duration = " + Duration );
                    System.out.println( "4. damage = " + Damage );
                    System.out.println( "5. upgrade level = " + Uplevel );
                    System.out.println( "6. upgrade cost = " + Upcost );
                    System.out.println( "7. character = " + Character);
                    System.out.println();
                }
                stmt.close();
                c.commit();
                c.close();
            }catch ( Exception e ) {
                System.err.println( e.getClass().getName() + ": " + e.getMessage() );
                System.exit(0);
            }
            int cardId=sc.nextInt();
            int edit=sc.nextInt();
            System.out.println("are you sure you want to edit this card?( y/n)");
            String confirm=sc.next();
            if (!getCommandStrMatcher(confirm,"yes").matches())
                return;
            if (getCommandStrMatcher(confirm,"yes").matches())
            {
                if (edit==1)
                {
                    System.out.print("name: ");
                    String editedValue=sc.next();
                    try{
                        Class.forName("org.sqlite.JDBC");
                        c = DriverManager.getConnection("jdbc:sqlite:test1.db");
                        c.setAutoCommit(false);
                        stmt = c.createStatement();
                        ResultSet rs = stmt.executeQuery( "SELECT * FROM CARDS2;" );
                        while ( rs.next() ) {
                            if (editedValue.equals(rs.getString("name")))
                            {
                                System.out.println("this name already exists");
                                return;
                            }
                        }
                        stmt.close();
                        c.commit();
                        c.close();
                    }catch ( Exception e ) {
                        System.err.println( e.getClass().getName() + ": " + e.getMessage() );
                        System.exit(0);
                    }
                    try{
                        Class.forName("org.sqlite.JDBC");
                        c = DriverManager.getConnection("jdbc:sqlite:test1.db");
                        c.setAutoCommit(false);

                        stmt = c.createStatement();
                        String sql = "UPDATE CARDS2 set NAME = '"+editedValue+"' where ID="+cardId+";";
                        stmt.executeUpdate(sql);
                        c.commit();

                        ResultSet rs = stmt.executeQuery( "SELECT * FROM CARDS2;" );
                        while ( rs.next() ) {
                            int Id=rs.getInt("id");
                            String Name = rs.getString("name");
                            int Attack= rs.getInt("attack");
                            int Duration= rs.getInt("duration");
                            int Damage= rs.getInt("damage");
                            int Uplevel= rs.getInt("uplevel");
                            int Upcost= rs.getInt("upcost");
                            int Character= rs.getInt("character");

                            System.out.println( "id = " + Id);
                            System.out.println( "name = " + Name);
                            System.out.println( "attack defence = " + Attack );
                            System.out.println( "duration = " + Duration );
                            System.out.println( "damage = " + Damage );
                            System.out.println( "upgrade level = " + Uplevel );
                            System.out.println( "upgrade cost = " + Upcost );
                            System.out.println( "character = " + Character);
                            System.out.println();
                        }
                        stmt.close();
                        c.commit();
                        c.close();
                    }catch ( Exception e ) {
                        System.err.println( e.getClass().getName() + ": " + e.getMessage() );
                        System.exit(0);
                    }
                }
                if (edit==2)
                {
                    System.out.print("attack defence: ");
                    int editedValue=sc.nextInt();
                    try{
                        Class.forName("org.sqlite.JDBC");
                        c = DriverManager.getConnection("jdbc:sqlite:test1.db");
                        c.setAutoCommit(false);

                        stmt = c.createStatement();
                        String sql = "UPDATE CARDS2 set ATTACK = "+editedValue+" where ID="+cardId+";";
                        stmt.executeUpdate(sql);
                        c.commit();

                        ResultSet rs = stmt.executeQuery( "SELECT * FROM CARDS2;" );
                        while ( rs.next() ) {
                            int Id=rs.getInt("id");
                            String Name = rs.getString("name");
                            int Attack= rs.getInt("attack");
                            int Duration= rs.getInt("duration");
                            int Damage= rs.getInt("damage");
                            int Uplevel= rs.getInt("uplevel");
                            int Upcost= rs.getInt("upcost");
                            int Character= rs.getInt("character");

                            System.out.println( "id = " + Id);
                            System.out.println( "name = " + Name);
                            System.out.println( "attack defence = " + Attack );
                            System.out.println( "duration = " + Duration );
                            System.out.println( "damage = " + Damage );
                            System.out.println( "upgrade level = " + Uplevel );
                            System.out.println( "upgrade cost = " + Upcost );
                            System.out.println( "character = " + Character);
                            System.out.println();
                        }
                        stmt.close();
                        c.commit();
                        c.close();
                    }catch ( Exception e ) {
                        System.err.println( e.getClass().getName() + ": " + e.getMessage() );
                        System.exit(0);
                    }
                }
                if (edit==3)
                {
                    System.out.print("duration: ");
                    int editedValue=sc.nextInt();
                    try{
                        Class.forName("org.sqlite.JDBC");
                        c = DriverManager.getConnection("jdbc:sqlite:test1.db");
                        c.setAutoCommit(false);

                        stmt = c.createStatement();
                        String sql = "UPDATE CARDS2 set DURATION = "+editedValue+" where ID="+cardId+";";
                        stmt.executeUpdate(sql);
                        c.commit();

                        ResultSet rs = stmt.executeQuery( "SELECT * FROM CARDS2;" );
                        while ( rs.next() ) {
                            int Id=rs.getInt("id");
                            String Name = rs.getString("name");
                            int Attack= rs.getInt("attack");
                            int Duration= rs.getInt("duration");
                            int Damage= rs.getInt("damage");
                            int Uplevel= rs.getInt("uplevel");
                            int Upcost= rs.getInt("upcost");
                            int Character= rs.getInt("character");

                            System.out.println( "id = " + Id);
                            System.out.println( "name = " + Name);
                            System.out.println( "attack defence = " + Attack );
                            System.out.println( "duration = " + Duration );
                            System.out.println( "damage = " + Damage );
                            System.out.println( "upgrade level = " + Uplevel );
                            System.out.println( "upgrade cost = " + Upcost );
                            System.out.println( "character = " + Character);
                            System.out.println();
                        }
                        stmt.close();
                        c.commit();
                        c.close();
                    }catch ( Exception e ) {
                        System.err.println( e.getClass().getName() + ": " + e.getMessage() );
                        System.exit(0);
                    }
                }
                if (edit==4)
                {
                    System.out.print("damage: ");
                    int editedValue=sc.nextInt();
                    try{
                        Class.forName("org.sqlite.JDBC");
                        c = DriverManager.getConnection("jdbc:sqlite:test1.db");
                        c.setAutoCommit(false);

                        stmt = c.createStatement();
                        String sql = "UPDATE CARDS2 set DAMAGE = "+editedValue+" where ID="+cardId+";";
                        stmt.executeUpdate(sql);
                        c.commit();

                        ResultSet rs = stmt.executeQuery( "SELECT * FROM CARDS2;" );
                        while ( rs.next() ) {
                            int Id=rs.getInt("id");
                            String Name = rs.getString("name");
                            int Attack= rs.getInt("attack");
                            int Duration= rs.getInt("duration");
                            int Damage= rs.getInt("damage");
                            int Uplevel= rs.getInt("uplevel");
                            int Upcost= rs.getInt("upcost");
                            int Character= rs.getInt("character");

                            System.out.println( "id = " + Id);
                            System.out.println( "name = " + Name);
                            System.out.println( "attack defence = " + Attack );
                            System.out.println( "duration = " + Duration );
                            System.out.println( "damage = " + Damage );
                            System.out.println( "upgrade level = " + Uplevel );
                            System.out.println( "upgrade cost = " + Upcost );
                            System.out.println( "character = " + Character);
                            System.out.println();
                        }
                        stmt.close();
                        c.commit();
                        c.close();
                    }catch ( Exception e ) {
                        System.err.println( e.getClass().getName() + ": " + e.getMessage() );
                        System.exit(0);
                    }
                }
                if (edit==5)
                {
                    System.out.print("update level: ");
                    int editedValue=sc.nextInt();
                    try{
                        Class.forName("org.sqlite.JDBC");
                        c = DriverManager.getConnection("jdbc:sqlite:test1.db");
                        c.setAutoCommit(false);

                        stmt = c.createStatement();
                        String sql = "UPDATE CARDS2 set UPLEVEL = "+editedValue+" where ID="+cardId+";";
                        stmt.executeUpdate(sql);
                        c.commit();

                        ResultSet rs = stmt.executeQuery( "SELECT * FROM CARDS2;" );
                        while ( rs.next() ) {
                            int Id=rs.getInt("id");
                            String Name = rs.getString("name");
                            int Attack= rs.getInt("attack");
                            int Duration= rs.getInt("duration");
                            int Damage= rs.getInt("damage");
                            int Uplevel= rs.getInt("uplevel");
                            int Upcost= rs.getInt("upcost");
                            int Character= rs.getInt("character");

                            System.out.println( "id = " + Id);
                            System.out.println( "name = " + Name);
                            System.out.println( "attack defence = " + Attack );
                            System.out.println( "duration = " + Duration );
                            System.out.println( "damage = " + Damage );
                            System.out.println( "upgrade level = " + Uplevel );
                            System.out.println( "upgrade cost = " + Upcost );
                            System.out.println( "character = " + Character);
                            System.out.println();
                        }
                        stmt.close();
                        c.commit();
                        c.close();
                    }catch ( Exception e ) {
                        System.err.println( e.getClass().getName() + ": " + e.getMessage() );
                        System.exit(0);
                    }
                }
                if (edit==6)
                {
                    System.out.print("update cost: ");
                    int editedValue=sc.nextInt();
                    try{
                        Class.forName("org.sqlite.JDBC");
                        c = DriverManager.getConnection("jdbc:sqlite:test1.db");
                        c.setAutoCommit(false);

                        stmt = c.createStatement();
                        String sql = "UPDATE CARDS2 set UPCOST = "+editedValue+" where ID="+cardId+";";
                        stmt.executeUpdate(sql);
                        c.commit();

                        ResultSet rs = stmt.executeQuery( "SELECT * FROM CARDS2;" );
                        while ( rs.next() ) {
                            int Id=rs.getInt("id");
                            String Name = rs.getString("name");
                            int Attack= rs.getInt("attack");
                            int Duration= rs.getInt("duration");
                            int Damage= rs.getInt("damage");
                            int Uplevel= rs.getInt("uplevel");
                            int Upcost= rs.getInt("upcost");
                            int Character= rs.getInt("character");

                            System.out.println( "id = " + Id);
                            System.out.println( "name = " + Name);
                            System.out.println( "attack defence = " + Attack );
                            System.out.println( "duration = " + Duration );
                            System.out.println( "damage = " + Damage );
                            System.out.println( "upgrade level = " + Uplevel );
                            System.out.println( "upgrade cost = " + Upcost );
                            System.out.println( "character = " + Character);
                            System.out.println();
                        }
                        stmt.close();
                        c.commit();
                        c.close();
                    }catch ( Exception e ) {
                        System.err.println( e.getClass().getName() + ": " + e.getMessage() );
                        System.exit(0);
                    }
                }
                if (edit==7)
                {
                    System.out.print("character: ");
                    int editedValue=sc.nextInt();
                    try{
                        Class.forName("org.sqlite.JDBC");
                        c = DriverManager.getConnection("jdbc:sqlite:test1.db");
                        c.setAutoCommit(false);

                        stmt = c.createStatement();
                        String sql = "UPDATE CARDS2 set CHARACTER = "+editedValue+" where ID="+cardId+";";
                        stmt.executeUpdate(sql);
                        c.commit();

                        ResultSet rs = stmt.executeQuery( "SELECT * FROM CARDS2;" );
                        while ( rs.next() ) {
                            int Id=rs.getInt("id");
                            String Name = rs.getString("name");
                            int Attack= rs.getInt("attack");
                            int Duration= rs.getInt("duration");
                            int Damage= rs.getInt("damage");
                            int Uplevel= rs.getInt("uplevel");
                            int Upcost= rs.getInt("upcost");
                            int Character= rs.getInt("character");

                            System.out.println( "id = " + Id);
                            System.out.println( "name = " + Name);
                            System.out.println( "attack defence = " + Attack );
                            System.out.println( "duration = " + Duration );
                            System.out.println( "damage = " + Damage );
                            System.out.println( "upgrade level = " + Uplevel );
                            System.out.println( "upgrade cost = " + Upcost );
                            System.out.println( "character = " + Character);
                            System.out.println();
                        }
                        stmt.close();
                        c.commit();
                        c.close();
                    }catch ( Exception e ) {
                        System.err.println( e.getClass().getName() + ": " + e.getMessage() );
                        System.exit(0);
                    }
                }
            }
        }
    }
    public void backInEdit (Matcher matcher)
    {
        if (matcher.matches())
        {
            System.out.println("back to main admin menu");
            menu=10;
        }
    }
    public void ShowPlayers (Matcher matcher)
    {
        if (matcher.matches())
        {
            try{
                Class.forName("org.sqlite.JDBC");
                c = DriverManager.getConnection("jdbc:sqlite:test1.db");
                c.setAutoCommit(false);
                stmt = c.createStatement();

                ResultSet rs = stmt.executeQuery( "SELECT * FROM USERS;" );
                while ( rs.next() ) {
                    String Id=rs.getString("username");
                    String Name = rs.getString("pass");
                    String Attack= rs.getString("nickname");
                    String Duration= rs.getString("email");
                    String Damage= rs.getString("pra");
                    int Uplevel= rs.getInt("prq");
                    String Upcost= rs.getString("cards");
                    int level=rs.getInt("level");
                    int coin=rs.getInt("coin");

                    System.out.println( "username = " + Id);
                    System.out.println( "password = " + Name);
                    System.out.println( "nickname = " + Attack );
                    System.out.println( "email = " + Duration );
                    System.out.println( "answer = " + Damage );
                    System.out.println( "question = " + Uplevel );
                    System.out.println( "cards = " + Upcost );
                    System.out.println( "level = " + level );
                    System.out.println( "coin = " + coin );
                    System.out.println();
                }
                stmt.close();
                c.commit();
                c.close();
            } catch ( Exception e ) {
                System.err.println( e.getClass().getName() + ": " + e.getMessage() );
                System.exit(0);
            }
        }
    }
    public void otherPlayerLogin (Matcher matcher)
    {
        if (matcher.matches())
        {
            if (matcher.matches())
            {
                long endTime=System.nanoTime();
                if (((endTime-startTime)/1000000000)<(n*5))
                {
                    System.out.println("Try again in "+((n*5)-((endTime-startTime)/1000000000))+" seconds");
                    return;
                }
                String username=matcher.group(1);
                String password=matcher.group(2);
                boolean exist=false;
                for (int i=0;i<Users.size();i++)
                {
                    if (username.equals(Users.get(i).Username))
                    {
                        exist=true;
                        otherPlayer=i;
                    }
                }
                if (!exist)
                {
                    System.out.println("Username doesn’t exist!");
                    otherPlayer=0;
                    return;
                }
                if (!Users.get(otherPlayer).Password.equals(password))
                {
                    System.out.println("Password and Username don’t match!");
                    startTime = System.nanoTime();
                    otherPlayer=0;
                    n++;
                    return;
                }
                System.out.println("user logged in successfully!");
                n=0;
            }
        }
    }
    public void gotoLoginMenu (Matcher matcher)
    {
        if (matcher.matches())
        {
            menu=1;
            System.out.println("moved to login menu");
        }
    }
    public void multiplayerGame(int loginIndex1 , int loginIndex2){
        int winnerIndex=0;
        String players="";
        players=players+Users.get(loginIndex1).Username+" "+Users.get(loginIndex2).Username;
        Date currentDateTime = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String currentDate = dateFormat.format(currentDateTime);
        cardsInGame[] table1 = new cardsInGame[21];
        cardsInGame[] table2 = new cardsInGame[21];
        int roundsLeft = 4;
        for (int i=0;i<21;i++)
        {
            table1[i]=new cardsInGame();
            table2[i]=new cardsInGame();
        }
        Random rand = new Random();
        int turn = rand.nextInt(10);
        int destroyed1 = rand.nextInt(21);
        int destroyed2 = rand.nextInt(21);

        table1[destroyed1].broken = true;
        table2[destroyed2].broken = true;

        ArrayList<Card> deck1 = new ArrayList<>();
        ArrayList<Card> deck2 = new ArrayList<>();

        Collections.shuffle(Users.get(loginIndex1).getCards());
        Collections.shuffle(Users.get(loginIndex2).getCards());

        for(int i = 0 ; i < 5 ; i++){
            deck1.add(Users.get(loginIndex1).getCards().get(i));
            deck2.add(Users.get(loginIndex2).getCards().get(i));
        }

        int playerDamage1 = 0;
        int playerDamage2 = 0;

        boolean hide1 = false; //mainly for the hide spell card
        boolean hide2 = false;

        int i1 = 5; // the number we have moved forward in the shuffled cards of the player
        int i2 = 5;

        int unEspecialPlayed1 = 0;
        int unEspecialPlayed2 = 0;

        boolean has6Cards1 = false; //mainly for the cards that can make a player have 6 cards
        boolean has6Cards2 = false;

        Scanner input = new Scanner(System.in);
        String inp;

        boolean winner = true;

        int hp1;
        int hp2;

        int char1;
        int char2;


        //choosing character
        while (true){ // player 1
            System.out.println("please choose your character :");
            inp = input.nextLine();
            if(getCommandMatcher(inp , choseChar).matches()){
                Matcher matcher = getCommandMatcher(inp , choseChar);
                matcher.matches();
                char1 = Integer.parseInt(matcher.group("code"));
                break;
            }
        }

        while (true){ // player 2
            System.out.println("please choose your character");
            inp = input.nextLine();
            if(getCommandMatcher(inp , choseChar).matches()){
                Matcher matcher = getCommandMatcher(inp , choseChar);
                matcher.matches();
                char2 = Integer.parseInt(matcher.group("code"));
                break;
            }
        }

        if(char1 == 0){
            hp1 = 1000;
        } else if (char1 == 1) {
            hp1 = 900;
        } else if (char1 == 2) {
            hp1 = 1100;
        } else {
            hp1 = 950;
        }

        if(char2 == 0){
            hp2 = 1000;
        } else if (char2 == 1) {
            hp2 = 900;
        } else if (char2 == 2) {
            hp2 = 1100;
        } else {
            hp2 = 950;
        }

        while(roundsLeft > 0){
            playerDamage1 = 0;
            playerDamage2 = 0;
            if(turn < 20){
                //chooses card to play

                while (true) { //while for the first player
                    System.out.println("choose a card to play");


                    System.out.println("using character " + char1);
                    if(!hide1) {
                        for (int j = 0; j < deck1.size(); j++) {
                            System.out.println((j + 1) + " " +deck1.get(j).getName() + " | attack/defence : " + deck1.get(j).getAttack_defence() + " | player damage : " + deck1.get(j).getPlayer_damage() + " | duration : " + deck1.get(j).getDuration() + " | character : " + deck1.get(j).getCharNum());
                        }
                    }

                    for(int j = 0 ; j < 21 ; j++){
                        if(table1[j].filled && table1[j].copy == -1){
                            if(table1[j].playeeCard.code() == 0){
                                System.out.print("shild|");
                            } else if(table1[j].playeeCard.code() == 1){
                                System.out.print("heall|");
                            } else {
                                System.out.print(table1[j].playeeCard.getAttack_defence() + "/" + table1[j].playeeCard.getPlayer_damage() + "|");
                            }

                        } else if (table1[j].filled && table1[j].copy != -1) {
                            if(table1[table1[j].copy].playeeCard.code() == 0){
                                System.out.print("shild|");
                            } else if (table1[table1[j].copy].playeeCard.code() == 1) {
                                System.out.print("heall|");
                            } else {
                                System.out.print(table1[table1[j].copy].playeeCard.getAttack_defence() + "/" + table1[table1[j].copy].playeeCard.getPlayer_damage() + "|");
                            }
                        } else {
                            if(table1[j].broken){
                                System.out.print("broke|");
                            } else {
                                System.out.print("empty|");
                            }
                        }
                    }

                    System.out.println("\n");

                    for(int j = 0 ; j < 21 ; j++){
                        if(table2[j].filled && table2[j].copy == -1){
                            if(table2[j].playeeCard.code() == 0){
                                System.out.print("shild|");
                            } else if(table2[j].playeeCard.code() == 1){
                                System.out.print("heall|");
                            } else {
                                System.out.print(table2[j].playeeCard.getAttack_defence() + "/" + table2[j].playeeCard.getPlayer_damage() + "|");
                            }

                        } else if (table2[j].filled && table2[j].copy != -1) {
                            if(table2[table2[j].copy].playeeCard.code() == 0){
                                System.out.print("shild|");
                            } else if (table2[table2[j].copy].playeeCard.code() == 1) {
                                System.out.print("heall|");
                            } else {
                                System.out.print(table2[table2[j].copy].playeeCard.getAttack_defence() + "/" + table2[table2[j].copy].playeeCard.getPlayer_damage() + "|");
                            }
                        } else {
                            if(table2[j].broken){
                                System.out.print("broke|");
                            } else {
                                System.out.print("empty|");
                            }
                        }
                    }

                    System.out.println("\n");

                    inp = input.nextLine();
                    if (getCommandMatcher(inp, playCard).matches()) {
                        Matcher matcher = getCommandMatcher(inp, playCard);
                        matcher.matches();
                        int card_id = Integer.parseInt(matcher.group("code")) - 1;
                        int card_loc = Integer.parseInt(matcher.group("location")) - 1;


                        if (deck1.get(card_id).IsTableable()) {
                            if ((card_loc <= destroyed1 && destroyed1 < card_loc + deck1.get(card_id).getDuration()) || card_loc + deck1.get(card_id).getDuration() > 21) {
                                System.out.println("you cant place the card in this location");
                            } else {
                                boolean possible = true;
                                for (int j = 0; j < deck1.get(card_id).getDuration(); j++) {
                                    if (table1[card_loc + j].filled) {
                                        possible = false;
                                        break;
                                    }
                                }

                                if (!possible) {
                                    System.out.println("you cant place the card in this location");
                                } else {
                                    table1[card_loc].playeeCard = deck1.get(card_id);
                                    for (int j = 0; j < deck1.get(card_id).getDuration(); j++) {
                                        table1[card_loc + j].filled = true;
                                        table1[card_loc + j].copy = card_loc;
                                    }
                                    table1[card_loc].copy = -1;
                                    System.out.println("card placed successfully");

                                    //number of unspecial cards played
                                    if(!deck1.get(card_id).getName().equals("shield") && !deck1.get(card_id).getName().equals("heal")){
                                        unEspecialPlayed1++;
                                    }

                                    //upgrading player's deck
                                    deck1.remove(card_id);
                                    if(has6Cards1){
                                        break;
                                    } else {
                                        i1++;
                                        if (i1 < Users.get(loginIndex1).getCards().size()) {
                                            deck1.add(Users.get(loginIndex1).getCards().get(i1 - 1));
                                        } else {
                                            deck1.add(Users.get(loginIndex1).getCards().get(i1 - 1));
                                            Collections.shuffle(Users.get(loginIndex1).getCards());
                                            i1 = 1;
                                        }

                                        break;
                                    }
                                }
                            }
                        } else { // else for special cards
                            int code = deck1.get(card_id).code();
                            if(code == 2){ //buff
                                if(unEspecialPlayed1 == 0){
                                    System.out.println("you can not currently play this card");
                                } else {
                                    int buffed_card = rand.nextInt(unEspecialPlayed1);
                                    int temp = 0;
                                    int buffed_index = 0;

                                    while(true){
                                        if(!table1[buffed_index].filled || table1[buffed_index].copy != -1){
                                            buffed_index++;
                                        } else if(!table1[buffed_index].playeeCard.IsSpecail()){
                                            temp++;
                                            if(temp == buffed_card - 1){
                                                break;
                                            } else {
                                                buffed_index++;
                                            }
                                        }
                                    }

                                    table1[buffed_index].playeeCard.setAttack_defence((int)Math.ceil(table1[buffed_index].playeeCard.getAttack_defence()*1.2));
                                    table1[buffed_index].playeeCard.setPlayer_damage((int)Math.ceil(table1[buffed_index].playeeCard.getPlayer_damage()*1.2));

                                    break;
                                }
                            } else if (code == 3) { // repair
                                boolean isRepaired = true;
                                int brokenIndex = 0;
                                for(int j = 0 ; j < 21 ; j++){
                                    if(table1[j].broken){
                                        isRepaired = false;
                                        brokenIndex = j;
                                        break;
                                    }
                                }
                                if(isRepaired){
                                    System.out.println("you cant currently play this card");
                                } else {
                                    table1[brokenIndex].broken = false;
                                    destroyed1 = -1;
                                    break;
                                }
                            } else if (code == 4) { //round dec
                                roundsLeft--;
                                break;
                            } else if (code == 5) { //remover    if the hole in both sides were removed the nothing will happen if the player play this card
                                if(table1[destroyed1].broken){
                                    int newHoleLock;
                                    while (true){
                                        newHoleLock = rand.nextInt(21);
                                        if(!table1[newHoleLock].filled && newHoleLock != destroyed1){
                                            table1[destroyed1].broken = false;
                                            destroyed1 = newHoleLock;
                                            table1[destroyed1].broken = true;
                                            break;
                                        }
                                    }
                                }

                                if(table2[destroyed2].broken){
                                    int newHoleLock;
                                    while (true){
                                        newHoleLock = rand.nextInt(21);
                                        if(!table2[newHoleLock].filled && newHoleLock != destroyed2){
                                            table2[destroyed2].broken = false;
                                            destroyed2 = newHoleLock;
                                            table2[destroyed2].broken = true;
                                            break;
                                        }
                                    }
                                }
                                break;

                            } else if (code == 6) { //debuffer
                                if(unEspecialPlayed2 == 0){
                                    System.out.println("you can not currently play this card");
                                } else {
                                    int debuffed_card = rand.nextInt(unEspecialPlayed2);
                                    int temp = 0;
                                    int debuffed_index = 0;

                                    while(true){
                                        if(!table2[debuffed_index].filled && table2[debuffed_index].copy != -1){
                                            debuffed_index++;
                                        } else if(!table2[debuffed_index].playeeCard.IsSpecail() && !table2[debuffed_index].filled && table2[debuffed_index].copy == -1){
                                            temp++;
                                            if(temp == debuffed_card){
                                                break;
                                            } else {
                                                debuffed_index++;
                                            }
                                        }
                                    }

                                    table2[debuffed_index].playeeCard.setAttack_defence((int)Math.ceil(table2[debuffed_index].playeeCard.getAttack_defence()*0.8));
                                    table2[debuffed_index].playeeCard.setPlayer_damage((int)Math.ceil(table2[debuffed_index].playeeCard.getPlayer_damage()*0.8));
                                    break;
                                }
                            } else if (code == 7) { //copy
                                int copied = card_loc;
                                deck1.add(deck1.get(copied));
                                has6Cards1 = true;
                                break;
                            } else if (code == 8) { //hider
                                hide2 = true;
                                Collections.shuffle(deck2);
                                break;
                            } else if (code == 9) { // magnet
                                if(!table1[destroyed1].broken){
                                    System.out.println("you can not play this card");
                                } else {
                                    if (!table2[destroyed1].filled) {
                                        System.out.println("you can not play this card");
                                    } else {
                                        if (table2[destroyed1].copy == -1) {
                                            table1[destroyed1].playeeCard = table2[destroyed1].playeeCard;
                                            table2[destroyed1].playeeCard = null;
                                            table2[destroyed1].filled = false;
                                        } else {
                                            table1[destroyed1].playeeCard = table2[table2[destroyed1].copy].playeeCard;
                                            table2[table2[destroyed1].copy].playeeCard = null;
                                            table2[table2[destroyed1].copy].filled = false;
                                        }
                                    }
                                    break;
                                }
                            }
                            //upgrading player's deck
                            deck1.remove(card_id);
                            if(has6Cards1){
                                break;
                            } else {
                                i1++;
                                if (i1 < Users.get(loginIndex1).getCards().size()) {
                                    deck1.add(Users.get(loginIndex1).getCards().get(i1 - 1));
                                } else {
                                    deck1.add(Users.get(loginIndex1).getCards().get(i1 - 1));
                                    Collections.shuffle(Users.get(loginIndex1).getCards());
                                    i1 = 1;
                                }

                                break;
                            }
                        }
                    }
                }
                while (true) { // second player
                    System.out.println("choose a card to play");


                    System.out.println("using character " + char2);
                    if(!hide2) {
                        for (int j = 0; j < deck2.size(); j++) {
                            System.out.println((j + 1) + " " +deck2.get(j).getName() + " | attack/defence : " + deck2.get(j).getAttack_defence() + " | player damage : " + deck2.get(j).getPlayer_damage() + " | duration : " + deck2.get(j).getDuration() +  " | character : " + deck2.get(j).getCharNum());
                        }
                    }

                    for(int j = 0 ; j < 21 ; j++){
                        if(table1[j].filled && table1[j].copy == -1){
                            if(table1[j].playeeCard.code() == 0){
                                System.out.print("shild|");
                            } else if(table1[j].playeeCard.code() == 1){
                                System.out.print("heall|");
                            } else {
                                System.out.print(table1[j].playeeCard.getAttack_defence() + "/" + table1[j].playeeCard.getPlayer_damage() + "|");
                            }

                        } else if (table1[j].filled && table1[j].copy != -1) {
                            if(table1[table1[j].copy].playeeCard.code() == 0){
                                System.out.print("shild|");
                            } else if (table1[table1[j].copy].playeeCard.code() == 1) {
                                System.out.print("heall|");
                            } else {
                                System.out.print(table1[table1[j].copy].playeeCard.getAttack_defence() + "/" + table1[table1[j].copy].playeeCard.getPlayer_damage() + "|");
                            }
                        } else {
                            if(table1[j].broken){
                                System.out.print("broke|");
                            } else {
                                System.out.print("empty|");
                            }
                        }
                    }

                    System.out.println("\n");

                    for(int j = 0 ; j < 21 ; j++){
                        if(table2[j].filled && table2[j].copy == -1){
                            if(table2[j].playeeCard.code() == 0){
                                System.out.print("shild|");
                            } else if(table2[j].playeeCard.code() == 1){
                                System.out.print("heall|");
                            } else {
                                System.out.print(table2[j].playeeCard.getAttack_defence() + "/" + table2[j].playeeCard.getPlayer_damage() + "|");
                            }

                        } else if (table2[j].filled && table2[j].copy != -1) {
                            if(table2[table2[j].copy].playeeCard.code() == 0){
                                System.out.print("shild|");
                            } else if (table2[table2[j].copy].playeeCard.code() == 1) {
                                System.out.print("heall|");
                            } else {
                                System.out.print(table2[table2[j].copy].playeeCard.getAttack_defence() + "/" + table2[table2[j].copy].playeeCard.getPlayer_damage() + "|");
                            }
                        } else {
                            if(table2[j].broken){
                                System.out.print("broke|");
                            } else {
                                System.out.print("empty|");
                            }
                        }
                    }

                    System.out.println("\n");

                    inp = input.nextLine();
                    if (getCommandMatcher(inp, playCard).matches()) {
                        Matcher matcher = getCommandMatcher(inp, playCard);
                        matcher.matches();
                        int card_id = Integer.parseInt(matcher.group("code")) - 1;
                        int card_loc = Integer.parseInt(matcher.group("location")) - 1;


                        if (deck2.get(card_id).IsTableable()) {
                            if ((card_loc <= destroyed2 && destroyed2 < card_loc + deck2.get(card_id).getDuration()) || card_loc + deck2.get(card_id).getDuration() > 21) {
                                System.out.println("you cant place the card in this location");
                            } else {
                                boolean possible = true;
                                for (int j = 0; j < deck2.get(card_id).getDuration(); j++) {
                                    if (table2[card_loc + j].filled) {
                                        possible = false;
                                        break;
                                    }
                                }

                                if (!possible) {
                                    System.out.println("you cant place the card in this location");
                                } else {
                                    table2[card_loc].playeeCard = deck2.get(card_id);
                                    for (int j = 0; j < deck2.get(card_id).getDuration(); j++) {
                                        table2[card_loc + j].filled = true;
                                        table2[card_loc + j].copy = card_loc;
                                    }
                                    table2[card_loc].copy = -1;
                                    System.out.println("card placed successfully");

                                    //updating the number of unspecail cards played
                                    if(!deck2.get(card_id).getName().equals("shield") && !deck2.get(card_id).getName().equals("heal")){
                                        unEspecialPlayed2++;
                                    }

                                    //upgrading player's deck
                                    deck2.remove(card_id);
                                    i2++;
                                    if(i2 < Users.get(loginIndex2).getCards().size()){
                                        deck2.add(Users.get(loginIndex2).getCards().get(i2 - 1));
                                    } else {
                                        deck2.add(Users.get(loginIndex2).getCards().get(i2 - 1));
                                        Collections.shuffle(Users.get(loginIndex2).getCards());
                                        i2 = 1;
                                    }

                                    break;
                                }
                            }
                        } else { // for special cards
                            int code = deck2.get(card_id).code();
                            if(code == 2){ //buff
                                if(unEspecialPlayed2 == 0){
                                    System.out.println("you can not currently play this card");
                                } else {
                                    int buffed_card = rand.nextInt(unEspecialPlayed2);
                                    int temp = 0;
                                    int buffed_index = 0;

                                    while(true){
                                        if(!table2[buffed_index].filled || table2[buffed_index].copy != -1){
                                            buffed_index++;
                                        } else if(!table2[buffed_index].playeeCard.IsSpecail()){
                                            temp++;
                                            if(temp == buffed_card - 1){
                                                break;
                                            } else {
                                                buffed_index++;
                                            }
                                        }
                                    }

                                    table2[buffed_index].playeeCard.setAttack_defence((int)Math.ceil(table2[buffed_index].playeeCard.getAttack_defence()*1.2));
                                    table2[buffed_index].playeeCard.setPlayer_damage((int)Math.ceil(table2[buffed_index].playeeCard.getPlayer_damage()*1.2));
                                    break;
                                }
                            } else if (code == 3) { // repair
                                boolean isRepaired = true;
                                int brokenIndex = 0;
                                for(int j = 0 ; j < 21 ; j++){
                                    if(table2[j].broken){
                                        isRepaired = false;
                                        brokenIndex = j;
                                        break;
                                    }
                                }
                                if(isRepaired){
                                    System.out.println("you cant currently play this card");
                                } else {
                                    table2[brokenIndex].broken = false;
                                    destroyed2 = -1;
                                    break;
                                }
                            } else if (code == 4) { //round dec
                                roundsLeft--;
                                break;
                            } else if (code == 5) { //remover    if the hole in both sides were removed the nothing will happen if the player play this card
                                if(table2[destroyed2].broken){
                                    int newHoleLock;
                                    while (true){
                                        newHoleLock = rand.nextInt(21);
                                        if(!table2[newHoleLock].filled && newHoleLock != destroyed2){
                                            table2[destroyed2].broken = false;
                                            destroyed2 = newHoleLock;
                                            table2[destroyed2].broken = true;
                                            break;
                                        }
                                    }
                                }

                                if(table1[destroyed1].broken){
                                    int newHoleLock;
                                    while (true){
                                        newHoleLock = rand.nextInt(21);
                                        if(!table1[newHoleLock].filled && newHoleLock != destroyed1){
                                            table1[destroyed1].broken = false;
                                            destroyed1 = newHoleLock;
                                            table1[destroyed1].broken = true;
                                            break;
                                        }
                                    }
                                }
                                break;

                            } else if (code == 6) { //debuffer
                                if(unEspecialPlayed1 == 0){
                                    System.out.println("you can not currently play this card");
                                } else {
                                    int debuffed_card = rand.nextInt(unEspecialPlayed1);
                                    int temp = 0;
                                    int debuffed_index = 0;

                                    while(true){
                                        if(!table1[debuffed_index].filled || table1[debuffed_index].copy != -1){
                                            debuffed_index++;
                                        } else if(!table1[debuffed_index].playeeCard.IsSpecail()){
                                            temp++;
                                            if(temp == debuffed_card - 1){
                                                break;
                                            } else {
                                                debuffed_index++;
                                            }
                                        }
                                    }

                                    table1[debuffed_index].playeeCard.setAttack_defence((int)Math.ceil(table1[debuffed_index].playeeCard.getAttack_defence()*0.8));
                                    table1[debuffed_index].playeeCard.setPlayer_damage((int)Math.ceil(table1[debuffed_index].playeeCard.getPlayer_damage()*0.8));
                                    break;
                                }
                            } else if (code == 7) { //copy
                                int copied = card_loc;
                                deck2.add(deck2.get(copied));
                                has6Cards2 = true;
                                break;
                            } else if (code == 8) { //hider
                                hide1 = true;
                                Collections.shuffle(deck1);
                                break;
                            } else if (code == 9) { // magnet
                                if(!table2[destroyed2].broken){
                                    System.out.println("you can not play this card");
                                } else {
                                    if(!table2[destroyed2].filled){
                                        System.out.println("you can not play this card");
                                    } else {
                                        table2[destroyed2].playeeCard = table1[destroyed2].playeeCard;
                                        table1[destroyed2].playeeCard = null;
                                        table1[destroyed2].filled = false;

                                        break;
                                    }
                                }
                            }

                            //upgrading player's deck
                            deck2.remove(card_id);
                            if(has6Cards2){
                                break;
                            } else {
                                i2++;
                                if (i2 < Users.get(loginIndex2).getCards().size()) {
                                    deck2.add(Users.get(loginIndex2).getCards().get(i2 - 1));
                                } else {
                                    deck2.add(Users.get(loginIndex2).getCards().get(i2 - 1));
                                    Collections.shuffle(Users.get(loginIndex2).getCards());
                                    i2 = 1;
                                }

                                break;
                            }
                        }
                    }
                }

            } else { // for the situation where the second players starts first

                while (true) { // second player
                    System.out.println("choose a card to play");

                    System.out.println("using character " + char2);
                    if(!hide2) {
                        for (int j = 0; j < deck2.size(); j++) {
                            System.out.println((j + 1) + deck2.get(j).getName() + " | attack/defence : " + deck2.get(j).getAttack_defence() + " | player damage :" + deck2.get(j).getPlayer_damage() +  " | character : " + deck2.get(j).getCharNum());
                        }
                    }

                    for(int j = 0 ; j < 21 ; j++){
                        if(table1[j].filled && table1[j].copy == -1){
                            System.out.print(table1[j].playeeCard.getAttack_defence() + "/" + table1[j].playeeCard.getPlayer_damage() +"|");
                        } else if (table1[j].filled && table1[j].copy != -1) {
                            System.out.print(table1[table1[j].copy].playeeCard.getAttack_defence() + "/" + table1[table1[j].copy].playeeCard.getPlayer_damage() +"|");
                        } else {
                            if(table1[j].broken){
                                System.out.print("broke|");
                            } else {
                                System.out.print("empty|");
                            }
                        }
                    }

                    System.out.println("\n");

                    for(int j = 0 ; j < 21 ; j++){
                        if(table2[j].filled && table2[j].copy == -1){
                            System.out.print(table2[j].playeeCard.getAttack_defence() + "/" + table2[j].playeeCard.getPlayer_damage() +"|");
                        } else if (table2[j].filled && table2[j].copy != -1) {
                            System.out.print(table2[table2[j].copy].playeeCard.getAttack_defence() + "/" + table2[table2[j].copy].playeeCard.getPlayer_damage() +"|");
                        } else {
                            if(table2[j].broken){
                                System.out.print("broke|");
                            } else {
                                System.out.print("empty|");
                            }
                        }
                    }

                    System.out.println("\n");

                    inp = input.nextLine();
                    if (getCommandMatcher(inp, playCard).matches()) {
                        Matcher matcher = getCommandMatcher(inp, playCard);
                        matcher.matches();
                        int card_id = Integer.parseInt(matcher.group("code")) - 1;
                        int card_loc = Integer.parseInt(matcher.group("location")) - 1;


                        if (deck2.get(card_id).IsTableable()) {
                            if ((card_loc <= destroyed2 && destroyed2 < card_loc + deck2.get(card_id).getDuration()) || card_loc + deck2.get(card_id).getDuration() > 21) {
                                System.out.println("you cant place the card in this location");
                            } else {
                                boolean possible = true;
                                for (int j = 0; j < deck2.get(card_id).getDuration(); j++) {
                                    if (table2[card_loc + j].filled) {
                                        possible = false;
                                        break;
                                    }
                                }

                                if (!possible) {
                                    System.out.println("you cant place the card in this location");
                                } else {
                                    table2[card_loc].playeeCard = deck2.get(card_id);
                                    for (int j = 0; j < deck2.get(card_id).getDuration(); j++) {
                                        table2[card_loc + j].filled = true;
                                        table2[card_loc + j].copy = card_loc;
                                    }
                                    table2[card_loc].copy = -1;
                                    System.out.println("card placed successfully");

                                    //updating the number of unspecail cards played
                                    if(!deck2.get(card_id).getName().equals("shield") && !deck2.get(card_id).getName().equals("heal")){
                                        unEspecialPlayed2++;
                                    }

                                    //upgrading player's deck
                                    deck2.remove(card_id);
                                    i2++;
                                    if(i2 < Users.get(loginIndex2).getCards().size()){
                                        deck2.add(Users.get(loginIndex2).getCards().get(i2 - 1));
                                    } else {
                                        deck2.add(Users.get(loginIndex2).getCards().get(i2 - 1));
                                        Collections.shuffle(Users.get(loginIndex2).getCards());
                                        i2 = 1;
                                    }

                                    break;
                                }
                            }
                        } else { // for special cards
                            int code = deck2.get(card_id).code();
                            if(code == 2){ //buff
                                if(unEspecialPlayed2 == 0){
                                    System.out.println("you can not currently play this card");
                                } else {
                                    int buffed_card = rand.nextInt(unEspecialPlayed2);
                                    int temp = 0;
                                    int buffed_index = 0;

                                    while(true){
                                        if(!table2[buffed_index].filled || table2[buffed_index].copy != -1){
                                            buffed_index++;
                                        } else if(!table2[buffed_index].playeeCard.IsSpecail()){
                                            temp++;
                                            if(temp == buffed_card - 1){
                                                break;
                                            } else {
                                                buffed_index++;
                                            }
                                        }
                                    }

                                    table2[buffed_index].playeeCard.setAttack_defence((int)Math.ceil(table2[buffed_index].playeeCard.getAttack_defence()*1.2));
                                    table2[buffed_index].playeeCard.setPlayer_damage((int)Math.ceil(table2[buffed_index].playeeCard.getPlayer_damage()*1.2));
                                    break;
                                }
                            } else if (code == 3) { // repair
                                boolean isRepaired = true;
                                int brokenIndex = 0;
                                for(int j = 0 ; j < 21 ; j++){
                                    if(table2[j].broken){
                                        isRepaired = false;
                                        brokenIndex = j;
                                        break;
                                    }
                                }
                                if(isRepaired){
                                    System.out.println("you cant currently play this card");
                                } else {
                                    table2[brokenIndex].broken = false;
                                    destroyed2 = -1;
                                    break;
                                }
                            } else if (code == 4) { //round dec
                                roundsLeft--;
                                break;
                            } else if (code == 5) { //remover    if the hole in both sides were removed the nothing will happen if the player play this card
                                if(table2[destroyed2].broken){
                                    int newHoleLock;
                                    while (true){
                                        newHoleLock = rand.nextInt(21);
                                        if(!table2[newHoleLock].filled && newHoleLock != destroyed2){
                                            table2[destroyed2].broken = false;
                                            destroyed2 = newHoleLock;
                                            table2[destroyed2].broken = true;
                                            break;
                                        }
                                    }
                                }

                                if(table1[destroyed1].broken){
                                    int newHoleLock;
                                    while (true){
                                        newHoleLock = rand.nextInt(21);
                                        if(!table1[newHoleLock].filled && newHoleLock != destroyed1){
                                            table1[destroyed1].broken = false;
                                            destroyed1 = newHoleLock;
                                            table1[destroyed1].broken = true;
                                            break;
                                        }
                                    }
                                }
                                break;

                            } else if (code == 6) { //debuffer
                                if(unEspecialPlayed1 == 0){
                                    System.out.println("you can not currently play this card");
                                } else {
                                    int debuffed_card = rand.nextInt(unEspecialPlayed1);
                                    int temp = 0;
                                    int debuffed_index = 0;

                                    while(true){
                                        if(!table1[debuffed_index].filled || table1[debuffed_index].copy != -1){
                                            debuffed_index++;
                                        } else if(!table1[debuffed_index].playeeCard.IsSpecail()){
                                            temp++;
                                            if(temp == debuffed_card - 1){
                                                break;
                                            } else {
                                                debuffed_index++;
                                            }
                                        }
                                    }

                                    table1[debuffed_index].playeeCard.setAttack_defence((int)Math.ceil(table1[debuffed_index].playeeCard.getAttack_defence()*0.8));
                                    table1[debuffed_index].playeeCard.setPlayer_damage((int)Math.ceil(table1[debuffed_index].playeeCard.getPlayer_damage()*0.8));
                                    break;
                                }
                            } else if (code == 7) { //copy
                                int copied = card_loc;
                                deck2.add(deck2.get(copied));
                                has6Cards2 = true;
                                break;
                            } else if (code == 8) { //hider
                                hide1 = true;
                                Collections.shuffle(deck1);
                                break;
                            } else if (code == 9) { // magnet
                                if(!table2[destroyed2].broken){
                                    System.out.println("you can not play this card");
                                } else {
                                    if(!table2[destroyed2].filled){
                                        System.out.println("you can not play this card");
                                    } else {
                                        table2[destroyed2].playeeCard = table1[destroyed2].playeeCard;
                                        table1[destroyed2].playeeCard = null;
                                        table1[destroyed2].filled = false;

                                        break;
                                    }
                                }
                            }
                        }
                    }
                }

                while (true) { //while for the first player
                    System.out.println("choose a card to play");

                    System.out.println("using character " + char1);
                    if(!hide1) {
                        for (int j = 0; j < deck1.size(); j++) {
                            System.out.println((j + 1) + deck1.get(j).getName() + " | attack/defence : " + deck1.get(j).getAttack_defence() + " | player damage :" + deck1.get(j).getPlayer_damage() +  " | character : " + deck1.get(j).getCharNum());
                        }
                    }

                    for(int j = 0 ; j < 21 ; j++){
                        if(table1[j].filled && table1[j].copy == -1){
                            System.out.print(table1[j].playeeCard.getAttack_defence() + "/" + table1[j].playeeCard.getPlayer_damage() +"|");
                        } else if (table1[j].filled && table1[j].copy != -1) {
                            System.out.print(table1[table1[j].copy].playeeCard.getAttack_defence() + "/" + table1[table1[j].copy].playeeCard.getPlayer_damage() +"|");
                        } else {
                            if(table1[j].broken){
                                System.out.print("broke|");
                            } else {
                                System.out.print("empty|");
                            }
                        }
                    }

                    System.out.println("\n");

                    for(int j = 0 ; j < 21 ; j++){
                        if(table2[j].filled && table2[j].copy == -1){
                            System.out.print(table2[j].playeeCard.getAttack_defence() + "/" + table2[j].playeeCard.getPlayer_damage() +"|");
                        } else if (table2[j].filled && table2[j].copy != -1) {
                            System.out.print(table2[table2[j].copy].playeeCard.getAttack_defence() + "/" + table2[table2[j].copy].playeeCard.getPlayer_damage() +"|");
                        } else {
                            if(table2[j].broken){
                                System.out.print("broke|");
                            } else {
                                System.out.print("empty|");
                            }
                        }
                    }

                    System.out.println("\n");

                    inp = input.nextLine();
                    if (getCommandMatcher(inp, playCard).matches()) {
                        Matcher matcher = getCommandMatcher(inp, playCard);
                        matcher.matches();
                        int card_id = Integer.parseInt(matcher.group("code")) - 1;
                        int card_loc = Integer.parseInt(matcher.group("location")) - 1;


                        if (deck1.get(card_id).IsTableable()) {
                            if ((card_loc <= destroyed1 && destroyed1 < card_loc + deck1.get(card_id).getDuration()) || card_loc + deck1.get(card_id).getDuration() > 21) {
                                System.out.println("you cant place the card in this location");
                            } else {
                                boolean possible = true;
                                for (int j = 0; j < deck1.get(card_id).getDuration(); j++) {
                                    if (table1[card_loc + j].filled) {
                                        possible = false;
                                        break;
                                    }
                                }

                                if (!possible) {
                                    System.out.println("you cant place the card in this location");
                                } else {
                                    table1[card_loc].playeeCard = deck1.get(card_id);
                                    for (int j = 0; j < deck1.get(card_id).getDuration(); j++) {
                                        table1[card_loc + j].filled = true;
                                        table1[card_loc + j].copy = card_loc;
                                    }
                                    table1[card_loc].copy = -1;
                                    System.out.println("card placed successfully");

                                    //number of unspecial cards played
                                    if(!deck1.get(card_id).getName().equals("shield") && !deck1.get(card_id).getName().equals("heal")){
                                        unEspecialPlayed1++;
                                    }

                                    //upgrading player's deck
                                    deck1.remove(card_id);
                                    if(has6Cards1){
                                        break;
                                    } else {
                                        i1++;
                                        if (i1 < Users.get(loginIndex1).getCards().size()) {
                                            deck1.add(Users.get(loginIndex1).getCards().get(i1 - 1));
                                        } else {
                                            deck1.add(Users.get(loginIndex1).getCards().get(i1 - 1));
                                            Collections.shuffle(Users.get(loginIndex1).getCards());
                                            i1 = 1;
                                        }

                                        break;
                                    }
                                }
                            }
                        } else { // else for special cards
                            int code = deck1.get(card_id).code();
                            if(code == 2){ //buff
                                if(unEspecialPlayed1 == 0){
                                    System.out.println("you can not currently play this card");
                                } else {
                                    int buffed_card = rand.nextInt(unEspecialPlayed1);
                                    int temp = 0;
                                    int buffed_index = 0;

                                    while(true){
                                        if(!table1[buffed_index].filled || table1[buffed_index].copy != -1){
                                            buffed_index++;
                                        } else if(!table1[buffed_index].playeeCard.IsSpecail()){
                                            temp++;
                                            if(temp == buffed_card - 1){
                                                break;
                                            } else {
                                                buffed_index++;
                                            }
                                        }
                                    }

                                    table1[buffed_index].playeeCard.setAttack_defence((int)Math.ceil(table1[buffed_index].playeeCard.getAttack_defence()*1.2));
                                    table1[buffed_index].playeeCard.setPlayer_damage((int)Math.ceil(table1[buffed_index].playeeCard.getPlayer_damage()*1.2));

                                    break;
                                }
                            } else if (code == 3) { // repair
                                boolean isRepaired = true;
                                int brokenIndex = 0;
                                for(int j = 0 ; j < 21 ; j++){
                                    if(table1[j].broken){
                                        isRepaired = false;
                                        brokenIndex = j;
                                        break;
                                    }
                                }
                                if(isRepaired){
                                    System.out.println("you cant currently play this card");
                                } else {
                                    table1[brokenIndex].broken = false;
                                    destroyed1 = -1;
                                    break;
                                }
                            } else if (code == 4) { //round dec
                                roundsLeft--;
                                break;
                            } else if (code == 5) { //remover    if the hole in both sides were removed the nothing will happen if the player play this card
                                if(table1[destroyed1].broken){
                                    int newHoleLock;
                                    while (true){
                                        newHoleLock = rand.nextInt(21);
                                        if(!table1[newHoleLock].filled && newHoleLock != destroyed1){
                                            table1[destroyed1].broken = false;
                                            destroyed1 = newHoleLock;
                                            table1[destroyed1].broken = true;
                                            break;
                                        }
                                    }
                                }

                                if(table2[destroyed2].broken){
                                    int newHoleLock;
                                    while (true){
                                        newHoleLock = rand.nextInt(21);
                                        if(!table2[newHoleLock].filled && newHoleLock != destroyed2){
                                            table2[destroyed2].broken = false;
                                            destroyed2 = newHoleLock;
                                            table2[destroyed2].broken = true;
                                            break;
                                        }
                                    }
                                }
                                break;

                            } else if (code == 6) { //debuffer
                                if(unEspecialPlayed2 == 0){
                                    System.out.println("you can not currently play this card");
                                } else {
                                    int debuffed_card = rand.nextInt(unEspecialPlayed2);
                                    int temp = 0;
                                    int debuffed_index = 0;

                                    while(true){
                                        if(!table2[debuffed_index].filled || table2[debuffed_index].copy != -1){
                                            debuffed_index++;
                                        } else if(!table2[debuffed_index].playeeCard.IsSpecail()){
                                            temp++;
                                            if(temp == debuffed_card - 1){
                                                break;
                                            } else {
                                                debuffed_index++;
                                            }
                                        }
                                    }

                                    table2[debuffed_index].playeeCard.setAttack_defence((int)Math.ceil(table2[debuffed_index].playeeCard.getAttack_defence()*0.8));
                                    table2[debuffed_index].playeeCard.setPlayer_damage((int)Math.ceil(table2[debuffed_index].playeeCard.getPlayer_damage()*0.8));
                                    break;
                                }
                            } else if (code == 7) { //copy
                                int copied = card_loc;
                                deck1.add(deck1.get(copied));
                                has6Cards1 = true;
                                break;
                            } else if (code == 8) { //hider
                                hide2 = true;
                                Collections.shuffle(deck2);
                                break;
                            } else if (code == 9) { // magnet
                                if(!table1[destroyed1].broken){
                                    System.out.println("you can not play this card");
                                } else {
                                    if(!table2[destroyed1].filled){
                                        System.out.println("you can not play this card");
                                    } else {
                                        if(table2[destroyed1].copy == -1) {
                                            table1[destroyed1].playeeCard = table2[destroyed1].playeeCard;
                                            table2[destroyed1].playeeCard = null;
                                            table2[destroyed1].filled = false;
                                        } else {
                                            table1[destroyed1].playeeCard = table2[table2[destroyed1].copy].playeeCard;
                                            table2[table2[destroyed1].copy].playeeCard = null;
                                            table2[table2[destroyed1].copy].filled = false;
                                        }
                                    }
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            //update the damage value
            for(int j = 0 ; j < 21 ; j++){
                if(table1[j].copy == -1 && table2[j].copy == -1) {
                    if (table1[j].isSuperior(table2[j]) == 1) {
                        table2[j].disable = true;
                        table1[j].disable = false;
                    } else if (table1[j].isSuperior(table2[j]) == -1) {
                        table1[j].disable = true;
                        table2[j].disable = false;
                    } else {
                        table1[j].disable = true;
                        table2[j].disable = true;
                    }
                } else if(table1[j].copy == -1) {
                    if (table1[j].isSuperior(table2[table2[j].copy]) == 1) {
                        table2[j].disable = true;
                        table1[j].disable = false;
                    } else if (table1[j].isSuperior(table2[table2[j].copy]) == -1) {
                        table1[j].disable = true;
                        table2[j].disable = false;
                    } else {
                        table1[j].disable = true;
                        table2[j].disable = true;
                    }
                } else if (table2[j].copy == -1) {
                    if (table1[table1[j].copy].isSuperior(table2[j]) == 1) {
                        table2[j].disable = true;
                        table1[j].disable = false;
                    } else if (table1[table1[j].copy].isSuperior(table2[j]) == -1) {
                        table1[j].disable = true;
                        table2[j].disable = false;
                    } else {
                        table1[j].disable = true;
                        table2[j].disable = true;
                    }
                } else {
                    if (table1[table1[j].copy].isSuperior(table2[table2[j].copy]) == 1) {
                        table2[j].disable = true;
                        table1[j].disable = false;
                    } else if (table1[table1[j].copy].isSuperior(table2[table2[j].copy]) == -1) {
                        table1[j].disable = true;
                        table2[j].disable = false;
                    } else {
                        table1[j].disable = true;
                        table2[j].disable = true;
                    }
                }
            }

            for(int j = 0 ; j < 21 ; j++){
                if(!table1[j].disable && table1[j].filled && table1[j].copy == -1){
                    if(table1[j].playeeCard.getCharNum() == char1){
                        playerDamage1 += (int)Math.ceil(table1[j].playeeCard.getPlayer_damage() * 1.1);
                    } else {
                        playerDamage1 += table1[j].playeeCard.getPlayer_damage();
                    }
                } else if(!table1[j].disable && table1[j].filled && table1[j].copy != -1){
                    if(table1[table1[j].copy].playeeCard.getCharNum() == char1){
                        playerDamage1 += (int)Math.ceil(table1[table1[j].copy].playeeCard.getPlayer_damage() * 1.1);
                    } else {
                        playerDamage1 += table1[table1[j].copy].playeeCard.getPlayer_damage();
                    }
                }

                if(!table2[j].disable && table2[j].filled && table2[j].copy == -1){
                    if(table2[j].playeeCard.getCharNum() == char2){
                        playerDamage2 += (int)Math.ceil(table2[j].playeeCard.getPlayer_damage() * 1.1);
                    } else {
                        playerDamage2 += table2[j].playeeCard.getPlayer_damage();
                    }
                } else if(!table2[j].disable && table2[j].filled && table2[j].copy != -1){
                    if(table2[table2[j].copy].playeeCard.getCharNum() == char2){
                        playerDamage2 += (int)Math.ceil(table2[table2[j].copy].playeeCard.getPlayer_damage() * 1.1);
                    } else {
                        playerDamage2 += table2[table2[j].copy].playeeCard.getPlayer_damage();
                    }
                }
            }

            for(int j = 0 ; j < 21 ; j++){
                if(table1[j].filled){
                    if(!table1[j].playeeCard.IsSpecail()) {
                        if(table1[j].filled && table1[j].copy == -1){
                            System.out.print(table1[j].playeeCard.getAttack_defence() + "/" + table1[j].playeeCard.getPlayer_damage() +"|");
                        } else if (table1[j].filled && table1[j].copy != -1) {
                            System.out.print(table1[table1[j].copy].playeeCard.getAttack_defence() + "/" + table1[table1[j].copy].playeeCard.getPlayer_damage() +"|");
                        }
                    } else {
                        if(table1[j].playeeCard.getName().equals("shield") && table1[j].copy == -1){
                            System.out.print("shild|");
                        } else if(table1[j].playeeCard.getName().equals("heal") && table1[j].copy == -1) {
                            System.out.print("heall|");
                        } else {
                            if(table1[table1[j].copy].playeeCard.getName().equals("shield")){
                                System.out.print("shild|");
                            } else {
                                System.out.print("heall|");
                            }
                        }
                    }
                } else {
                    if(table1[j].broken){
                        System.out.print("broke|");
                    } else {
                        System.out.print("empty|");
                    }
                }
            }

            roundsLeft--;

            System.out.print("player1's damage :"  + playerDamage1 + "   rounds left :" + roundsLeft);
            System.out.println("\n");

            for(int j = 0 ; j < 21 ; j++){
                if(table2[j].filled){
                    if(!table2[j].playeeCard.IsSpecail()) {
                        if(table2[j].filled && table2[j].copy == -1){
                            System.out.print(table2[j].playeeCard.getAttack_defence() + "/" + table2[j].playeeCard.getPlayer_damage() +"|");
                        } else if (table2[j].filled && table2[j].copy != -1) {
                            System.out.print(table2[table2[j].copy].playeeCard.getAttack_defence() + "/" + table2[table2[j].copy].playeeCard.getPlayer_damage() +"|");
                        }
                    } else {
                        if(table2[j].playeeCard.getName().equals("shield") && table2[j].copy == -1){
                            System.out.print("shild|");
                        } else if(table2[j].playeeCard.getName().equals("heal") && table2[j].copy == -1) {
                            System.out.print("heall|");
                        } else {
                            if(table2[table2[j].copy].playeeCard.getName().equals("shield")){
                                System.out.print("shild|");
                            } else {
                                System.out.print("heall|");
                            }
                        }
                    }
                } else {
                    if(table2[j].broken){
                        System.out.print("broke|");
                    } else {
                        System.out.print("empty|");
                    }

                }
            }

            System.out.print("player2's damage :"  + playerDamage2 + "   rounds left :" + roundsLeft);
            System.out.println("\n");

            hide1 = false;
            hide2 = false;

        }

        //time line

        boolean shield1 = false;
        boolean shield2 = false;

        boolean determined = false;

        for(int i = 0 ; i < 21 ; i++){
            if(table1[i].copy == -1){
                if(table1[i].playeeCard.IsSpecail()){
                    if(table1[i].playeeCard.code() == 0){
                        shield1 = true;
                    } else if(table1[i].playeeCard.code() == 1){
                        hp1 += 10;
                    }
                } else {
                    if(shield2){
                        shield2 = false;
                    } else {
                        hp2 -= table1[i].playeeCard.getPlayer_damage();
                    }
                }
            } else {
                if(table1[table1[i].copy].playeeCard.IsSpecail()){
                    if(table1[table1[i].copy].playeeCard.code() == 0){
                        shield1 = true;
                    } else if(table1[table1[i].copy].playeeCard.code() == 1){
                        hp1 += 10;
                    }
                } else {
                    if(shield2){
                        shield2 = false;
                    } else {
                        hp2 -= table1[table1[i].copy].playeeCard.getPlayer_damage();
                    }
                }
            }

            if(table2[i].copy == -1){
                if(table2[i].playeeCard.IsSpecail()){
                    if(table2[i].playeeCard.code() == 0){
                        shield2 = true;
                    } else if(table2[i].playeeCard.code() == 1){
                        hp2 += 10;
                    }
                } else {
                    if(shield1){
                        shield1 = false;
                    } else {
                        hp1 -= table2[i].playeeCard.getPlayer_damage();
                    }
                }
            } else {
                if(table2[table2[i].copy].playeeCard.IsSpecail()){
                    if(table2[table2[i].copy].playeeCard.code() == 0){
                        shield2 = true;
                    } else if(table2[table2[i].copy].playeeCard.code() == 1){
                        hp2 += 10;
                    }
                } else {
                    if(shield1){
                        shield1 = false;
                    } else {
                        hp1 -= table2[table2[i].copy].playeeCard.getPlayer_damage();
                    }
                }
            }

            if(hp1 <= 0 && hp2 <= 0){
                if(hp1 >= hp2){
                    winner = true;
                    determined = true;
                    break;
                } else {
                    winner = false;
                    determined = true;
                    break;
                }
            }

            if(hp1 <= 0){
                winner = false;
                determined = true;
                break;
            }

            if(hp2 <= 0){
                winner = true;
                determined = true;
                break;
            }
        }

        boolean even = false;

        if(!determined){
            if(hp1 > hp2){
                winner = true;
            } else if(hp1 < hp2) {
                winner = false;
            } else {
                even = true;
            }
        }

        if(even){
            System.out.println("the result is even");
        } else {
            if (winner) {
                winnerIndex=loginIndex1;
                System.out.println("player one is victorious");
                Users.get(loginIndex1).PRQ += 10;
            } else {
                winnerIndex=loginIndex2;
                System.out.println("player two is victorious");
                Users.get(loginIndex2).PRQ += 10;
            }
        }
        try{
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:test1.db");
            c.setAutoCommit(false);
//            stmt = c.createStatement();
//                String sql = "CREATE TABLE HISTORY " +
//                        "(DATE          TEXT     NOT NULL," +
//                        " PLAYERS       TEXT     NOT NULL, " +
//                        " WINNER        TEXT     NOT NULL)";
//                stmt.executeUpdate(sql);

            String sql2 = "INSERT INTO HISTORY (DATE,PLAYERS,WINNER) " +
                    "VALUES ('"+currentDate+"', '"+players+"', '"+Users.get(winnerIndex).Username+"');";

            stmt.executeUpdate(sql2);
            stmt.close();
            c.commit();
            c.close();
        } catch ( Exception e ) {
            System.err.println( e.getClass().getName() + ": " + e.getMessage() );
            System.exit(0);
        }
    }
    public Matcher getCommandMatcher(String input, Pattern regex) {
        Matcher matcher = regex.matcher(input);
        return matcher;
    }


    public void gamblingMode (int loginIndex1 , int loginIndex2 , int coin) {

        boolean possibleMode = false;

        if (Users.get(loginIndex1).getCoins() >= coin && Users.get(loginIndex2).getCoins() >= coin) {
            possibleMode = true;
        }

        if (possibleMode) {
            cardsInGame[] table1 = new cardsInGame[21];
            cardsInGame[] table2 = new cardsInGame[21];
            int roundsLeft = 4;
            for (int i = 0; i < 21; i++) {
                table1[i] = new cardsInGame();
                table2[i] = new cardsInGame();
            }
            Random rand = new Random();
            int turn = rand.nextInt(10);
            int destroyed1 = rand.nextInt(21);
            int destroyed2 = rand.nextInt(21);

            table1[destroyed1].broken = true;
            table2[destroyed2].broken = true;

            ArrayList<Card> deck1 = new ArrayList<>();
            ArrayList<Card> deck2 = new ArrayList<>();

            Collections.shuffle(Users.get(loginIndex1).getCards());
            Collections.shuffle(Users.get(loginIndex2).getCards());

            for (int i = 0; i < 5; i++) {
                deck1.add(Users.get(loginIndex1).getCards().get(i));
                deck2.add(Users.get(loginIndex2).getCards().get(i));
            }

            int playerDamage1 = 0;
            int playerDamage2 = 0;

            boolean hide1 = false; //mainly for the hide spell card
            boolean hide2 = false;

            int i1 = 5; // the number we have moved forward in the shuffled cards of the player
            int i2 = 5;

            int unEspecialPlayed1 = 0;
            int unEspecialPlayed2 = 0;

            boolean has6Cards1 = false; //mainly for the cards that can make a player have 6 cards
            boolean has6Cards2 = false;

            Scanner input = new Scanner(System.in);
            String inp;

            boolean winner = true;

            int hp1;
            int hp2;

            int char1;
            int char2;


            //choosing character
            while (true) { // player 1
                System.out.println("please choose your character :");
                inp = input.nextLine();
                if (getCommandMatcher(inp, choseChar).matches()) {
                    Matcher matcher = getCommandMatcher(inp, choseChar);
                    matcher.matches();
                    char1 = Integer.parseInt(matcher.group("code"));
                    break;
                }
            }

            while (true) { // player 2
                System.out.println("please choose your character");
                inp = input.nextLine();
                if (getCommandMatcher(inp, choseChar).matches()) {
                    Matcher matcher = getCommandMatcher(inp, choseChar);
                    matcher.matches();
                    char2 = Integer.parseInt(matcher.group("code"));
                    break;
                }
            }

            if (char1 == 0) {
                hp1 = 1000;
            } else if (char1 == 1) {
                hp1 = 900;
            } else if (char1 == 2) {
                hp1 = 1100;
            } else {
                hp1 = 950;
            }

            if (char2 == 0) {
                hp2 = 1000;
            } else if (char2 == 1) {
                hp2 = 900;
            } else if (char2 == 2) {
                hp2 = 1100;
            } else {
                hp2 = 950;
            }

            while (roundsLeft > 0) {
                playerDamage1 = 0;
                playerDamage2 = 0;
                if (turn < 20) {
                    //chooses card to play

                    while (true) { //while for the first player
                        System.out.println("choose a card to play");


                        System.out.println("using character " + char1);
                        if (!hide1) {
                            for (int j = 0; j < deck1.size(); j++) {
                                System.out.println((j + 1) + " " + deck1.get(j).getName() + " | attack/defence : " + deck1.get(j).getAttack_defence() + " | player damage : " + deck1.get(j).getPlayer_damage() + " | duration : " + deck1.get(j).getDuration() + " | character : " + deck1.get(j).getCharNum());
                            }
                        }

                        for (int j = 0; j < 21; j++) {
                            if (table1[j].filled && table1[j].copy == -1) {
                                System.out.print(table1[j].playeeCard.getAttack_defence() + "/" + table1[j].playeeCard.getPlayer_damage() + "|");
                            } else if (table1[j].filled && table1[j].copy != -1) {
                                System.out.print(table1[table1[j].copy].playeeCard.getAttack_defence() + "/" + table1[table1[j].copy].playeeCard.getPlayer_damage() + "|");
                            } else {
                                if (table1[j].broken) {
                                    System.out.print("broke|");
                                } else {
                                    System.out.print("empty|");
                                }
                            }
                        }
                        System.out.println("\n");
                        for (int j = 0; j < 21; j++) {
                            if (table2[j].filled && table2[j].copy == -1) {
                                System.out.print(table2[j].playeeCard.getAttack_defence() + "/" + table2[j].playeeCard.getPlayer_damage() + "|");
                            } else if (table2[j].filled && table2[j].copy != -1) {
                                System.out.print(table2[table2[j].copy].playeeCard.getAttack_defence() + "/" + table2[table2[j].copy].playeeCard.getPlayer_damage() + "|");
                            } else {
                                if (table2[j].broken) {
                                    System.out.print("broke|");
                                } else {
                                    System.out.print("empty|");
                                }
                            }
                        }
                        System.out.println("\n");

                        inp = input.nextLine();
                        if (getCommandMatcher(inp, playCard).matches()) {
                            Matcher matcher = getCommandMatcher(inp, playCard);
                            matcher.matches();
                            int card_id = Integer.parseInt(matcher.group("code")) - 1;
                            int card_loc = Integer.parseInt(matcher.group("location")) - 1;


                            if (deck1.get(card_id).IsTableable()) {
                                if ((card_loc <= destroyed1 && destroyed1 < card_loc + deck1.get(card_id).getDuration()) || card_loc + deck1.get(card_id).getDuration() > 21) {
                                    System.out.println("you cant place the card in this location");
                                } else {
                                    boolean possible = true;
                                    for (int j = 0; j < deck1.get(card_id).getDuration(); j++) {
                                        if (table1[card_loc + j].filled) {
                                            possible = false;
                                            break;
                                        }
                                    }

                                    if (!possible) {
                                        System.out.println("you cant place the card in this location");
                                    } else {
                                        table1[card_loc].playeeCard = deck1.get(card_id);
                                        for (int j = 0; j < deck1.get(card_id).getDuration(); j++) {
                                            table1[card_loc + j].filled = true;
                                            table1[card_loc + j].copy = card_loc;
                                        }
                                        table1[card_loc].copy = -1;
                                        System.out.println("card placed successfully");

                                        //number of unspecial cards played
                                        if (!deck1.get(card_id).getName().equals("shield") && !deck1.get(card_id).getName().equals("heal")) {
                                            unEspecialPlayed1++;
                                        }

                                        //upgrading player's deck
                                        deck1.remove(card_id);
                                        if (has6Cards1) {
                                            break;
                                        } else {
                                            i1++;
                                            if (i1 < Users.get(loginIndex1).getCards().size()) {
                                                deck1.add(Users.get(loginIndex1).getCards().get(i1 - 1));
                                            } else {
                                                deck1.add(Users.get(loginIndex1).getCards().get(i1 - 1));
                                                Collections.shuffle(Users.get(loginIndex1).getCards());
                                                i1 = 1;
                                            }

                                            break;
                                        }
                                    }
                                }
                            } else { // else for special cards
                                int code = deck1.get(card_id).code();
                                if (code == 2) { //buff
                                    if (unEspecialPlayed1 == 0) {
                                        System.out.println("you can not currently play this card");
                                    } else {
                                        int buffed_card = rand.nextInt(unEspecialPlayed1);
                                        int temp = 0;
                                        int buffed_index = 0;

                                        while (true) {
                                            if (!table1[buffed_index].filled || table1[buffed_index].copy != -1) {
                                                buffed_index++;
                                            } else if (!table1[buffed_index].playeeCard.IsSpecail()) {
                                                temp++;
                                                if (temp == buffed_card - 1) {
                                                    break;
                                                } else {
                                                    buffed_index++;
                                                }
                                            }
                                        }

                                        table1[buffed_index].playeeCard.setAttack_defence((int) Math.ceil(table1[buffed_index].playeeCard.getAttack_defence() * 1.2));
                                        table1[buffed_index].playeeCard.setPlayer_damage((int) Math.ceil(table1[buffed_index].playeeCard.getPlayer_damage() * 1.2));

                                        break;
                                    }
                                } else if (code == 3) { // repair
                                    boolean isRepaired = true;
                                    int brokenIndex = 0;
                                    for (int j = 0; j < 21; j++) {
                                        if (table1[j].broken) {
                                            isRepaired = false;
                                            brokenIndex = j;
                                            break;
                                        }
                                    }
                                    if (isRepaired) {
                                        System.out.println("you cant currently play this card");
                                    } else {
                                        table1[brokenIndex].broken = false;
                                        destroyed1 = -1;
                                        break;
                                    }
                                } else if (code == 4) { //round dec
                                    roundsLeft--;
                                    break;
                                } else if (code == 5) { //remover    if the hole in both sides were removed the nothing will happen if the player play this card
                                    if (table1[destroyed1].broken) {
                                        int newHoleLock;
                                        while (true) {
                                            newHoleLock = rand.nextInt(21);
                                            if (!table1[newHoleLock].filled && newHoleLock != destroyed1) {
                                                table1[destroyed1].broken = false;
                                                destroyed1 = newHoleLock;
                                                table1[destroyed1].broken = true;
                                                break;
                                            }
                                        }
                                    }

                                    if (table2[destroyed2].broken) {
                                        int newHoleLock;
                                        while (true) {
                                            newHoleLock = rand.nextInt(21);
                                            if (!table2[newHoleLock].filled && newHoleLock != destroyed2) {
                                                table2[destroyed2].broken = false;
                                                destroyed2 = newHoleLock;
                                                table2[destroyed2].broken = true;
                                                break;
                                            }
                                        }
                                    }
                                    break;

                                } else if (code == 6) { //debuffer
                                    if (unEspecialPlayed2 == 0) {
                                        System.out.println("you can not currently play this card");
                                    } else {
                                        int debuffed_card = rand.nextInt(unEspecialPlayed2);
                                        int temp = 0;
                                        int debuffed_index = 0;

                                        while (true) {
                                            if (!table2[debuffed_index].filled || table2[debuffed_index].copy != -1) {
                                                debuffed_index++;
                                            } else if (!table2[debuffed_index].playeeCard.IsSpecail()) {
                                                temp++;
                                                if (temp == debuffed_card - 1) {
                                                    break;
                                                } else {
                                                    debuffed_index++;
                                                }
                                            }
                                        }

                                        table2[debuffed_index].playeeCard.setAttack_defence((int) Math.ceil(table2[debuffed_index].playeeCard.getAttack_defence() * 0.8));
                                        table2[debuffed_index].playeeCard.setPlayer_damage((int) Math.ceil(table2[debuffed_index].playeeCard.getPlayer_damage() * 0.8));
                                        break;
                                    }
                                } else if (code == 7) { //copy
                                    int copied = card_loc;
                                    deck1.add(deck1.get(copied));
                                    has6Cards1 = true;
                                    break;
                                } else if (code == 8) { //hider
                                    hide2 = true;
                                    Collections.shuffle(deck2);
                                    break;
                                } else if (code == 9) { // magnet
                                    if (!table1[destroyed1].broken) {
                                        System.out.println("you can not play this card");
                                    } else {
                                        if (!table2[destroyed1].filled) {
                                            System.out.println("you can not play this card");
                                        } else {
                                            table1[destroyed1].playeeCard = table2[destroyed1].playeeCard;
                                            table2[destroyed1].playeeCard = null;
                                            table2[destroyed1].filled = false;
                                        }
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    while (true) { // second player
                        System.out.println("choose a card to play");


                        System.out.println("using character " + char2);
                        if (!hide2) {
                            for (int j = 0; j < deck2.size(); j++) {
                                System.out.println((j + 1) + " " + deck2.get(j).getName() + " | attack/defence : " + deck2.get(j).getAttack_defence() + " | player damage : " + deck2.get(j).getPlayer_damage() + " | duration : " + deck2.get(j).getDuration() + " | character : " + deck2.get(j).getCharNum());
                            }
                        }

                        for (int j = 0; j < 21; j++) {
                            if (table1[j].filled && table1[j].copy == -1) {
                                System.out.print(table1[j].playeeCard.getAttack_defence() + "/" + table1[j].playeeCard.getPlayer_damage() + "|");
                            } else if (table1[j].filled && table1[j].copy != -1) {
                                System.out.print(table1[table1[j].copy].playeeCard.getAttack_defence() + "/" + table1[table1[j].copy].playeeCard.getPlayer_damage() + "|");
                            } else {
                                if (table1[j].broken) {
                                    System.out.print("broke|");
                                } else {
                                    System.out.print("empty|");
                                }
                            }
                        }

                        System.out.println("\n");

                        for (int j = 0; j < 21; j++) {
                            if (table2[j].filled && table2[j].copy == -1) {
                                System.out.print(table2[j].playeeCard.getAttack_defence() + "/" + table2[j].playeeCard.getPlayer_damage() + "|");
                            } else if (table2[j].filled && table2[j].copy != -1) {
                                System.out.print(table2[table2[j].copy].playeeCard.getAttack_defence() + "/" + table2[table2[j].copy].playeeCard.getPlayer_damage() + "|");
                            } else {
                                if (table2[j].broken) {
                                    System.out.print("broke|");
                                } else {
                                    System.out.print("empty|");
                                }
                            }
                        }

                        System.out.println("\n");

                        inp = input.nextLine();
                        if (getCommandMatcher(inp, playCard).matches()) {
                            Matcher matcher = getCommandMatcher(inp, playCard);
                            matcher.matches();
                            int card_id = Integer.parseInt(matcher.group("code")) - 1;
                            int card_loc = Integer.parseInt(matcher.group("location")) - 1;


                            if (deck2.get(card_id).IsTableable()) {
                                if ((card_loc <= destroyed2 && destroyed2 < card_loc + deck2.get(card_id).getDuration()) || card_loc + deck2.get(card_id).getDuration() > 21) {
                                    System.out.println("you cant place the card in this location");
                                } else {
                                    boolean possible = true;
                                    for (int j = 0; j < deck2.get(card_id).getDuration(); j++) {
                                        if (table2[card_loc + j].filled) {
                                            possible = false;
                                            break;
                                        }
                                    }

                                    if (!possible) {
                                        System.out.println("you cant place the card in this location");
                                    } else {
                                        table2[card_loc].playeeCard = deck2.get(card_id);
                                        for (int j = 0; j < deck2.get(card_id).getDuration(); j++) {
                                            table2[card_loc + j].filled = true;
                                            table2[card_loc + j].copy = card_loc;
                                        }
                                        table2[card_loc].copy = -1;
                                        System.out.println("card placed successfully");

                                        //updating the number of unspecail cards played
                                        if (!deck2.get(card_id).getName().equals("shield") && !deck2.get(card_id).getName().equals("heal")) {
                                            unEspecialPlayed2++;
                                        }

                                        //upgrading player's deck
                                        deck2.remove(card_id);
                                        i2++;
                                        if (i2 < Users.get(loginIndex2).getCards().size()) {
                                            deck2.add(Users.get(loginIndex2).getCards().get(i2 - 1));
                                        } else {
                                            deck2.add(Users.get(loginIndex2).getCards().get(i2 - 1));
                                            Collections.shuffle(Users.get(loginIndex2).getCards());
                                            i2 = 1;
                                        }

                                        break;
                                    }
                                }
                            } else { // for special cards
                                int code = deck2.get(card_id).code();
                                if (code == 2) { //buff
                                    if (unEspecialPlayed2 == 0) {
                                        System.out.println("you can not currently play this card");
                                    } else {
                                        int buffed_card = rand.nextInt(unEspecialPlayed2);
                                        int temp = 0;
                                        int buffed_index = 0;

                                        while (true) {
                                            if (!table2[buffed_index].filled || table2[buffed_index].copy != -1) {
                                                buffed_index++;
                                            } else if (!table2[buffed_index].playeeCard.IsSpecail()) {
                                                temp++;
                                                if (temp == buffed_card - 1) {
                                                    break;
                                                } else {
                                                    buffed_index++;
                                                }
                                            }
                                        }

                                        table2[buffed_index].playeeCard.setAttack_defence((int) Math.ceil(table2[buffed_index].playeeCard.getAttack_defence() * 1.2));
                                        table2[buffed_index].playeeCard.setPlayer_damage((int) Math.ceil(table2[buffed_index].playeeCard.getPlayer_damage() * 1.2));
                                        break;
                                    }
                                } else if (code == 3) { // repair
                                    boolean isRepaired = true;
                                    int brokenIndex = 0;
                                    for (int j = 0; j < 21; j++) {
                                        if (table2[j].broken) {
                                            isRepaired = false;
                                            brokenIndex = j;
                                            break;
                                        }
                                    }
                                    if (isRepaired) {
                                        System.out.println("you cant currently play this card");
                                    } else {
                                        table2[brokenIndex].broken = false;
                                        destroyed2 = -1;
                                        break;
                                    }
                                } else if (code == 4) { //round dec
                                    roundsLeft--;
                                    break;
                                } else if (code == 5) { //remover    if the hole in both sides were removed the nothing will happen if the player play this card
                                    if (table2[destroyed2].broken) {
                                        int newHoleLock;
                                        while (true) {
                                            newHoleLock = rand.nextInt(21);
                                            if (!table2[newHoleLock].filled && newHoleLock != destroyed2) {
                                                table2[destroyed2].broken = false;
                                                destroyed2 = newHoleLock;
                                                table2[destroyed2].broken = true;
                                                break;
                                            }
                                        }
                                    }

                                    if (table1[destroyed1].broken) {
                                        int newHoleLock;
                                        while (true) {
                                            newHoleLock = rand.nextInt(21);
                                            if (!table1[newHoleLock].filled && newHoleLock != destroyed1) {
                                                table1[destroyed1].broken = false;
                                                destroyed1 = newHoleLock;
                                                table1[destroyed1].broken = true;
                                                break;
                                            }
                                        }
                                    }
                                    break;

                                } else if (code == 6) { //debuffer
                                    if (unEspecialPlayed1 == 0) {
                                        System.out.println("you can not currently play this card");
                                    } else {
                                        int debuffed_card = rand.nextInt(unEspecialPlayed1);
                                        int temp = 0;
                                        int debuffed_index = 0;

                                        while (true) {
                                            if (!table1[debuffed_index].filled || table1[debuffed_index].copy != -1) {
                                                debuffed_index++;
                                            } else if (!table1[debuffed_index].playeeCard.IsSpecail()) {
                                                temp++;
                                                if (temp == debuffed_card - 1) {
                                                    break;
                                                } else {
                                                    debuffed_index++;
                                                }
                                            }
                                        }

                                        table1[debuffed_index].playeeCard.setAttack_defence((int) Math.ceil(table1[debuffed_index].playeeCard.getAttack_defence() * 0.8));
                                        table1[debuffed_index].playeeCard.setPlayer_damage((int) Math.ceil(table1[debuffed_index].playeeCard.getPlayer_damage() * 0.8));
                                        break;
                                    }
                                } else if (code == 7) { //copy
                                    int copied = card_loc;
                                    deck2.add(deck2.get(copied));
                                    has6Cards2 = true;
                                    break;
                                } else if (code == 8) { //hider
                                    hide1 = true;
                                    Collections.shuffle(deck1);
                                    break;
                                } else if (code == 9) { // magnet
                                    if (!table2[destroyed2].broken) {
                                        System.out.println("you can not play this card");
                                    } else {
                                        if (!table2[destroyed2].filled) {
                                            System.out.println("you can not play this card");
                                        } else {
                                            table2[destroyed2].playeeCard = table1[destroyed2].playeeCard;
                                            table1[destroyed2].playeeCard = null;
                                            table1[destroyed2].filled = false;

                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }

                } else { // for the situation where the second players starts first

                    while (true) { // second player
                        System.out.println("choose a card to play");

                        System.out.println("using character " + char2);
                        if (!hide2) {
                            for (int j = 0; j < deck2.size(); j++) {
                                System.out.println((j + 1) + deck2.get(j).getName() + " | attack/defence : " + deck2.get(j).getAttack_defence() + " | player damage :" + deck2.get(j).getPlayer_damage() + " | character : " + deck2.get(j).getCharNum());
                            }
                        }

                        for (int j = 0; j < 21; j++) {
                            if (table1[j].filled && table1[j].copy == -1) {
                                System.out.print(table1[j].playeeCard.getAttack_defence() + "/" + table1[j].playeeCard.getPlayer_damage() + "|");
                            } else if (table1[j].filled && table1[j].copy != -1) {
                                System.out.print(table1[table1[j].copy].playeeCard.getAttack_defence() + "/" + table1[table1[j].copy].playeeCard.getPlayer_damage() + "|");
                            } else {
                                if (table1[j].broken) {
                                    System.out.print("broke|");
                                } else {
                                    System.out.print("empty|");
                                }
                            }
                        }

                        System.out.println("\n");

                        for (int j = 0; j < 21; j++) {
                            if (table2[j].filled && table2[j].copy == -1) {
                                System.out.print(table2[j].playeeCard.getAttack_defence() + "/" + table2[j].playeeCard.getPlayer_damage() + "|");
                            } else if (table2[j].filled && table2[j].copy != -1) {
                                System.out.print(table2[table2[j].copy].playeeCard.getAttack_defence() + "/" + table2[table2[j].copy].playeeCard.getPlayer_damage() + "|");
                            } else {
                                if (table2[j].broken) {
                                    System.out.print("broke|");
                                } else {
                                    System.out.print("empty|");
                                }
                            }
                        }

                        System.out.println("\n");

                        inp = input.nextLine();
                        if (getCommandMatcher(inp, playCard).matches()) {
                            Matcher matcher = getCommandMatcher(inp, playCard);
                            matcher.matches();
                            int card_id = Integer.parseInt(matcher.group("code")) - 1;
                            int card_loc = Integer.parseInt(matcher.group("location")) - 1;


                            if (deck2.get(card_id).IsTableable()) {
                                if ((card_loc <= destroyed2 && destroyed2 < card_loc + deck2.get(card_id).getDuration()) || card_loc + deck2.get(card_id).getDuration() > 21) {
                                    System.out.println("you cant place the card in this location");
                                } else {
                                    boolean possible = true;
                                    for (int j = 0; j < deck2.get(card_id).getDuration(); j++) {
                                        if (table2[card_loc + j].filled) {
                                            possible = false;
                                            break;
                                        }
                                    }

                                    if (!possible) {
                                        System.out.println("you cant place the card in this location");
                                    } else {
                                        table2[card_loc].playeeCard = deck2.get(card_id);
                                        for (int j = 0; j < deck2.get(card_id).getDuration(); j++) {
                                            table2[card_loc + j].filled = true;
                                            table2[card_loc + j].copy = card_loc;
                                        }
                                        table2[card_loc].copy = -1;
                                        System.out.println("card placed successfully");

                                        //updating the number of unspecail cards played
                                        if (!deck2.get(card_id).getName().equals("shield") && !deck2.get(card_id).getName().equals("heal")) {
                                            unEspecialPlayed2++;
                                        }

                                        //upgrading player's deck
                                        deck2.remove(card_id);
                                        i2++;
                                        if (i2 < Users.get(loginIndex2).getCards().size()) {
                                            deck2.add(Users.get(loginIndex2).getCards().get(i2 - 1));
                                        } else {
                                            deck2.add(Users.get(loginIndex2).getCards().get(i2 - 1));
                                            Collections.shuffle(Users.get(loginIndex2).getCards());
                                            i2 = 1;
                                        }

                                        break;
                                    }
                                }
                            } else { // for special cards
                                int code = deck2.get(card_id).code();
                                if (code == 2) { //buff
                                    if (unEspecialPlayed2 == 0) {
                                        System.out.println("you can not currently play this card");
                                    } else {
                                        int buffed_card = rand.nextInt(unEspecialPlayed2);
                                        int temp = 0;
                                        int buffed_index = 0;

                                        while (true) {
                                            if (!table2[buffed_index].filled || table2[buffed_index].copy != -1) {
                                                buffed_index++;
                                            } else if (!table2[buffed_index].playeeCard.IsSpecail()) {
                                                temp++;
                                                if (temp == buffed_card - 1) {
                                                    break;
                                                } else {
                                                    buffed_index++;
                                                }
                                            }
                                        }

                                        table2[buffed_index].playeeCard.setAttack_defence((int) Math.ceil(table2[buffed_index].playeeCard.getAttack_defence() * 1.2));
                                        table2[buffed_index].playeeCard.setPlayer_damage((int) Math.ceil(table2[buffed_index].playeeCard.getPlayer_damage() * 1.2));
                                        break;
                                    }
                                } else if (code == 3) { // repair
                                    boolean isRepaired = true;
                                    int brokenIndex = 0;
                                    for (int j = 0; j < 21; j++) {
                                        if (table2[j].broken) {
                                            isRepaired = false;
                                            brokenIndex = j;
                                            break;
                                        }
                                    }
                                    if (isRepaired) {
                                        System.out.println("you cant currently play this card");
                                    } else {
                                        table2[brokenIndex].broken = false;
                                        destroyed2 = -1;
                                        break;
                                    }
                                } else if (code == 4) { //round dec
                                    roundsLeft--;
                                    break;
                                } else if (code == 5) { //remover    if the hole in both sides were removed the nothing will happen if the player play this card
                                    if (table2[destroyed2].broken) {
                                        int newHoleLock;
                                        while (true) {
                                            newHoleLock = rand.nextInt(21);
                                            if (!table2[newHoleLock].filled && newHoleLock != destroyed2) {
                                                table2[destroyed2].broken = false;
                                                destroyed2 = newHoleLock;
                                                table2[destroyed2].broken = true;
                                                break;
                                            }
                                        }
                                    }

                                    if (table1[destroyed1].broken) {
                                        int newHoleLock;
                                        while (true) {
                                            newHoleLock = rand.nextInt(21);
                                            if (!table1[newHoleLock].filled && newHoleLock != destroyed1) {
                                                table1[destroyed1].broken = false;
                                                destroyed1 = newHoleLock;
                                                table1[destroyed1].broken = true;
                                                break;
                                            }
                                        }
                                    }
                                    break;

                                } else if (code == 6) { //debuffer
                                    if (unEspecialPlayed1 == 0) {
                                        System.out.println("you can not currently play this card");
                                    } else {
                                        int debuffed_card = rand.nextInt(unEspecialPlayed1);
                                        int temp = 0;
                                        int debuffed_index = 0;

                                        while (true) {
                                            if (!table1[debuffed_index].filled || table1[debuffed_index].copy != -1) {
                                                debuffed_index++;
                                            } else if (!table1[debuffed_index].playeeCard.IsSpecail()) {
                                                temp++;
                                                if (temp == debuffed_card - 1) {
                                                    break;
                                                } else {
                                                    debuffed_index++;
                                                }
                                            }
                                        }

                                        table1[debuffed_index].playeeCard.setAttack_defence((int) Math.ceil(table1[debuffed_index].playeeCard.getAttack_defence() * 0.8));
                                        table1[debuffed_index].playeeCard.setPlayer_damage((int) Math.ceil(table1[debuffed_index].playeeCard.getPlayer_damage() * 0.8));
                                        break;
                                    }
                                } else if (code == 7) { //copy
                                    int copied = card_loc;
                                    deck2.add(deck2.get(copied));
                                    has6Cards2 = true;
                                    break;
                                } else if (code == 8) { //hider
                                    hide1 = true;
                                    Collections.shuffle(deck1);
                                    break;
                                } else if (code == 9) { // magnet
                                    if (!table2[destroyed2].broken) {
                                        System.out.println("you can not play this card");
                                    } else {
                                        if (!table2[destroyed2].filled) {
                                            System.out.println("you can not play this card");
                                        } else {
                                            table2[destroyed2].playeeCard = table1[destroyed2].playeeCard;
                                            table1[destroyed2].playeeCard = null;
                                            table1[destroyed2].filled = false;

                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }

                    while (true) { //while for the first player
                        System.out.println("choose a card to play");

                        System.out.println("using character " + char1);
                        if (!hide1) {
                            for (int j = 0; j < deck1.size(); j++) {
                                System.out.println((j + 1) + deck1.get(j).getName() + " | attack/defence : " + deck1.get(j).getAttack_defence() + " | player damage :" + deck1.get(j).getPlayer_damage() + " | character : " + deck1.get(j).getCharNum());
                            }
                        }

                        for (int j = 0; j < 21; j++) {
                            if (table1[j].filled && table1[j].copy == -1) {
                                System.out.print(table1[j].playeeCard.getAttack_defence() + "/" + table1[j].playeeCard.getPlayer_damage() + "|");
                            } else if (table1[j].filled && table1[j].copy != -1) {
                                System.out.print(table1[table1[j].copy].playeeCard.getAttack_defence() + "/" + table1[table1[j].copy].playeeCard.getPlayer_damage() + "|");
                            } else {
                                if (table1[j].broken) {
                                    System.out.print("broke|");
                                } else {
                                    System.out.print("empty|");
                                }
                            }
                        }

                        System.out.println("\n");

                        for (int j = 0; j < 21; j++) {
                            if (table2[j].filled && table2[j].copy == -1) {
                                System.out.print(table2[j].playeeCard.getAttack_defence() + "/" + table2[j].playeeCard.getPlayer_damage() + "|");
                            } else if (table2[j].filled && table2[j].copy != -1) {
                                System.out.print(table2[table2[j].copy].playeeCard.getAttack_defence() + "/" + table2[table2[j].copy].playeeCard.getPlayer_damage() + "|");
                            } else {
                                if (table2[j].broken) {
                                    System.out.print("broke|");
                                } else {
                                    System.out.print("empty|");
                                }
                            }
                        }

                        System.out.println("\n");

                        inp = input.nextLine();
                        if (getCommandMatcher(inp, playCard).matches()) {
                            Matcher matcher = getCommandMatcher(inp, playCard);
                            matcher.matches();
                            int card_id = Integer.parseInt(matcher.group("code")) - 1;
                            int card_loc = Integer.parseInt(matcher.group("location")) - 1;


                            if (deck1.get(card_id).IsTableable()) {
                                if ((card_loc <= destroyed1 && destroyed1 < card_loc + deck1.get(card_id).getDuration()) || card_loc + deck1.get(card_id).getDuration() > 21) {
                                    System.out.println("you cant place the card in this location");
                                } else {
                                    boolean possible = true;
                                    for (int j = 0; j < deck1.get(card_id).getDuration(); j++) {
                                        if (table1[card_loc + j].filled) {
                                            possible = false;
                                            break;
                                        }
                                    }

                                    if (!possible) {
                                        System.out.println("you cant place the card in this location");
                                    } else {
                                        table1[card_loc].playeeCard = deck1.get(card_id);
                                        for (int j = 0; j < deck1.get(card_id).getDuration(); j++) {
                                            table1[card_loc + j].filled = true;
                                            table1[card_loc + j].copy = card_loc;
                                        }
                                        table1[card_loc].copy = -1;
                                        System.out.println("card placed successfully");

                                        //number of unspecial cards played
                                        if (!deck1.get(card_id).getName().equals("shield") && !deck1.get(card_id).getName().equals("heal")) {
                                            unEspecialPlayed1++;
                                        }

                                        //upgrading player's deck
                                        deck1.remove(card_id);
                                        if (has6Cards1) {
                                            break;
                                        } else {
                                            i1++;
                                            if (i1 < Users.get(loginIndex1).getCards().size()) {
                                                deck1.add(Users.get(loginIndex1).getCards().get(i1 - 1));
                                            } else {
                                                deck1.add(Users.get(loginIndex1).getCards().get(i1 - 1));
                                                Collections.shuffle(Users.get(loginIndex1).getCards());
                                                i1 = 1;
                                            }

                                            break;
                                        }
                                    }
                                }
                            } else { // else for special cards
                                int code = deck1.get(card_id).code();
                                if (code == 2) { //buff
                                    if (unEspecialPlayed1 == 0) {
                                        System.out.println("you can not currently play this card");
                                    } else {
                                        int buffed_card = rand.nextInt(unEspecialPlayed1);
                                        int temp = 0;
                                        int buffed_index = 0;

                                        while (true) {
                                            if (!table1[buffed_index].filled || table1[buffed_index].copy != -1) {
                                                buffed_index++;
                                            } else if (!table1[buffed_index].playeeCard.IsSpecail()) {
                                                temp++;
                                                if (temp == buffed_card - 1) {
                                                    break;
                                                } else {
                                                    buffed_index++;
                                                }
                                            }
                                        }

                                        table1[buffed_index].playeeCard.setAttack_defence((int) Math.ceil(table1[buffed_index].playeeCard.getAttack_defence() * 1.2));
                                        table1[buffed_index].playeeCard.setPlayer_damage((int) Math.ceil(table1[buffed_index].playeeCard.getPlayer_damage() * 1.2));

                                        break;
                                    }
                                } else if (code == 3) { // repair
                                    boolean isRepaired = true;
                                    int brokenIndex = 0;
                                    for (int j = 0; j < 21; j++) {
                                        if (table1[j].broken) {
                                            isRepaired = false;
                                            brokenIndex = j;
                                            break;
                                        }
                                    }
                                    if (isRepaired) {
                                        System.out.println("you cant currently play this card");
                                    } else {
                                        table1[brokenIndex].broken = false;
                                        destroyed1 = -1;
                                        break;
                                    }
                                } else if (code == 4) { //round dec
                                    roundsLeft--;
                                    break;
                                } else if (code == 5) { //remover    if the hole in both sides were removed the nothing will happen if the player play this card
                                    if (table1[destroyed1].broken) {
                                        int newHoleLock;
                                        while (true) {
                                            newHoleLock = rand.nextInt(21);
                                            if (!table1[newHoleLock].filled && newHoleLock != destroyed1) {
                                                table1[destroyed1].broken = false;
                                                destroyed1 = newHoleLock;
                                                table1[destroyed1].broken = true;
                                                break;
                                            }
                                        }
                                    }

                                    if (table2[destroyed2].broken) {
                                        int newHoleLock;
                                        while (true) {
                                            newHoleLock = rand.nextInt(21);
                                            if (!table2[newHoleLock].filled && newHoleLock != destroyed2) {
                                                table2[destroyed2].broken = false;
                                                destroyed2 = newHoleLock;
                                                table2[destroyed2].broken = true;
                                                break;
                                            }
                                        }
                                    }
                                    break;

                                } else if (code == 6) { //debuffer
                                    if (unEspecialPlayed2 == 0) {
                                        System.out.println("you can not currently play this card");
                                    } else {
                                        int debuffed_card = rand.nextInt(unEspecialPlayed2);
                                        int temp = 0;
                                        int debuffed_index = 0;

                                        while (true) {
                                            if (!table2[debuffed_index].filled || table2[debuffed_index].copy != -1) {
                                                debuffed_index++;
                                            } else if (!table2[debuffed_index].playeeCard.IsSpecail()) {
                                                temp++;
                                                if (temp == debuffed_card - 1) {
                                                    break;
                                                } else {
                                                    debuffed_index++;
                                                }
                                            }
                                        }

                                        table2[debuffed_index].playeeCard.setAttack_defence((int) Math.ceil(table2[debuffed_index].playeeCard.getAttack_defence() * 0.8));
                                        table2[debuffed_index].playeeCard.setPlayer_damage((int) Math.ceil(table2[debuffed_index].playeeCard.getPlayer_damage() * 0.8));
                                        break;
                                    }
                                } else if (code == 7) { //copy
                                    int copied = card_loc;
                                    deck1.add(deck1.get(copied));
                                    has6Cards1 = true;
                                    break;
                                } else if (code == 8) { //hider
                                    hide2 = true;
                                    Collections.shuffle(deck2);
                                    break;
                                } else if (code == 9) { // magnet
                                    if (!table1[destroyed1].broken) {
                                        System.out.println("you can not play this card");
                                    } else {
                                        if (!table2[destroyed1].filled) {
                                            System.out.println("you can not play this card");
                                        } else {
                                            table1[destroyed1].playeeCard = table2[destroyed1].playeeCard;
                                            table2[destroyed1].playeeCard = null;
                                            table2[destroyed1].filled = false;
                                        }
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
                //update the damage value
                for (int j = 0; j < 21; j++) {
                    if (table1[j].copy == -1 && table2[j].copy == -1) {
                        if (table1[j].isSuperior(table2[j]) == 1) {
                            table2[j].disable = true;
                            table1[j].disable = false;
                        } else if (table1[j].isSuperior(table2[j]) == -1) {
                            table1[j].disable = true;
                            table2[j].disable = false;
                        } else {
                            table1[j].disable = true;
                            table2[j].disable = true;
                        }
                    } else if (table1[j].copy == -1) {
                        if (table1[j].isSuperior(table2[table2[j].copy]) == 1) {
                            table2[j].disable = true;
                            table1[j].disable = false;
                        } else if (table1[j].isSuperior(table2[table2[j].copy]) == -1) {
                            table1[j].disable = true;
                            table2[j].disable = false;
                        } else {
                            table1[j].disable = true;
                            table2[j].disable = true;
                        }
                    } else if (table2[j].copy == -1) {
                        if (table1[table1[j].copy].isSuperior(table2[j]) == 1) {
                            table2[j].disable = true;
                            table1[j].disable = false;
                        } else if (table1[table1[j].copy].isSuperior(table2[j]) == -1) {
                            table1[j].disable = true;
                            table2[j].disable = false;
                        } else {
                            table1[j].disable = true;
                            table2[j].disable = true;
                        }
                    } else {
                        if (table1[table1[j].copy].isSuperior(table2[table2[j].copy]) == 1) {
                            table2[j].disable = true;
                            table1[j].disable = false;
                        } else if (table1[table1[j].copy].isSuperior(table2[table2[j].copy]) == -1) {
                            table1[j].disable = true;
                            table2[j].disable = false;
                        } else {
                            table1[j].disable = true;
                            table2[j].disable = true;
                        }
                    }
                }

                for (int j = 0; j < 21; j++) {
                    if (!table1[j].disable && table1[j].filled && table1[j].copy == -1) {
                        if (table1[j].playeeCard.getCharNum() == char1) {
                            playerDamage1 += (int) Math.ceil(table1[j].playeeCard.getPlayer_damage() * 1.1);
                        } else {
                            playerDamage1 += table1[j].playeeCard.getPlayer_damage();
                        }
                    } else if (!table1[j].disable && table1[j].filled && table1[j].copy != -1) {
                        if (table1[table1[j].copy].playeeCard.getCharNum() == char1) {
                            playerDamage1 += (int) Math.ceil(table1[table1[j].copy].playeeCard.getPlayer_damage() * 1.1);
                        } else {
                            playerDamage1 += table1[table1[j].copy].playeeCard.getPlayer_damage();
                        }
                    }

                    if (!table2[j].disable && table2[j].filled && table2[j].copy == -1) {
                        if (table2[j].playeeCard.getCharNum() == char2) {
                            playerDamage2 += (int) Math.ceil(table2[j].playeeCard.getPlayer_damage() * 1.1);
                        } else {
                            playerDamage2 += table2[j].playeeCard.getPlayer_damage();
                        }
                    } else if (!table2[j].disable && table2[j].filled && table2[j].copy != -1) {
                        if (table2[table2[j].copy].playeeCard.getCharNum() == char2) {
                            playerDamage2 += (int) Math.ceil(table2[table2[j].copy].playeeCard.getPlayer_damage() * 1.1);
                        } else {
                            playerDamage2 += table2[table2[j].copy].playeeCard.getPlayer_damage();
                        }
                    }
                }

                for (int j = 0; j < 21; j++) {
                    if (table1[j].filled) {
                        if (table1[j].playeeCard.IsTableable()) {
                            if (table1[j].filled && table1[j].copy == -1) {
                                System.out.print(table1[j].playeeCard.getAttack_defence() + "/" + table1[j].playeeCard.getPlayer_damage() + "|");
                            } else if (table1[j].filled && table1[j].copy != -1) {
                                System.out.print(table1[table1[j].copy].playeeCard.getAttack_defence() + "/" + table1[table1[j].copy].playeeCard.getPlayer_damage() + "|");
                            }
                        } else {
                            if (table1[j].playeeCard.getName().equals("shield") && table1[j].copy == -1) {
                                System.out.print("shild|");
                            } else if (table1[j].playeeCard.getName().equals("heal") && table1[j].copy == -1) {
                                System.out.print("heall|");
                            } else {
                                if (table1[table1[j].copy].playeeCard.getName().equals("shield")) {
                                    System.out.print("shild|");
                                } else {
                                    System.out.print("heall|");
                                }
                            }
                        }
                    } else {
                        if(table1[j].broken){
                            System.out.print("broke|");
                        } else {
                            System.out.print("empty|");
                        }
                    }
                }

                System.out.print("player1's damage :" + playerDamage1 + "   rounds left :" + roundsLeft);
                System.out.println("\n");

                for (int j = 0; j < 21; j++) {
                    if (table2[j].filled) {
                        if (table2[j].playeeCard.IsTableable()) {
                            if (table2[j].filled && table2[j].copy == -1) {
                                System.out.print(table2[j].playeeCard.getAttack_defence() + "/" + table2[j].playeeCard.getPlayer_damage() + "|");
                            } else if (table2[j].filled && table2[j].copy != -1) {
                                System.out.print(table2[table2[j].copy].playeeCard.getAttack_defence() + "/" + table2[table2[j].copy].playeeCard.getPlayer_damage() + "|");
                            }
                        } else {
                            if (table2[j].playeeCard.getName().equals("shield") && table2[j].copy == -1) {
                                System.out.print("shild|");
                            } else if (table2[j].playeeCard.getName().equals("heal") && table2[j].copy == -1) {
                                System.out.print("heall|");
                            } else {
                                if (table2[table2[j].copy].playeeCard.getName().equals("shield")) {
                                    System.out.print("shild|");
                                } else {
                                    System.out.print("heall|");
                                }
                            }
                        }
                    } else {
                        if(table2[j].broken){
                            System.out.print("broke|");
                        } else {
                            System.out.print("empty|");
                        }
                    }
                }

                roundsLeft--;

                System.out.print("player2's damage :" + playerDamage2 + "   rounds left :" + roundsLeft);
                System.out.println("\n");

                hide1 = false;
                hide2 = false;

            }

            //time line

            boolean shield1 = false;
            boolean shield2 = false;

            boolean determined = false;

            for (int i = 0; i < 21; i++) {
                if (table1[i].copy == -1) {
                    if (table1[i].playeeCard.IsSpecail()) {
                        if (table1[i].playeeCard.code() == 0) {
                            shield1 = true;
                        } else if (table1[i].playeeCard.code() == 1) {
                            hp1 += 10;
                        }
                    } else {
                        if (shield2) {
                            shield2 = false;
                        } else {
                            hp2 -= table1[i].playeeCard.getPlayer_damage();
                        }
                    }
                } else {
                    if (table1[table1[i].copy].playeeCard.IsSpecail()) {
                        if (table1[table1[i].copy].playeeCard.code() == 0) {
                            shield1 = true;
                        } else if (table1[table1[i].copy].playeeCard.code() == 1) {
                            hp1 += 10;
                        }
                    } else {
                        if (shield2) {
                            shield2 = false;
                        } else {
                            hp2 -= table1[table1[i].copy].playeeCard.getPlayer_damage();
                        }
                    }
                }

                if (table2[i].copy == -1) {
                    if (table2[i].playeeCard.IsSpecail()) {
                        if (table2[i].playeeCard.code() == 0) {
                            shield2 = true;
                        } else if (table2[i].playeeCard.code() == 1) {
                            hp2 += 10;
                        }
                    } else {
                        if (shield1) {
                            shield1 = false;
                        } else {
                            hp1 -= table2[i].playeeCard.getPlayer_damage();
                        }
                    }
                } else {
                    if (table2[table2[i].copy].playeeCard.IsSpecail()) {
                        if (table2[table2[i].copy].playeeCard.code() == 0) {
                            shield2 = true;
                        } else if (table2[table2[i].copy].playeeCard.code() == 1) {
                            hp2 += 10;
                        }
                    } else {
                        if (shield1) {
                            shield1 = false;
                        } else {
                            hp1 -= table2[table2[i].copy].playeeCard.getPlayer_damage();
                        }
                    }
                }

                if (hp1 <= 0 && hp2 <= 0) {
                    if (hp1 >= hp2) {
                        winner = true;
                        determined = true;
                        break;
                    } else {
                        winner = false;
                        determined = true;
                        break;
                    }
                }

                if (hp1 <= 0) {
                    winner = false;
                    determined = true;
                    break;
                }

                if (hp2 <= 0) {
                    winner = true;
                    determined = true;
                    break;
                }
            }

            boolean even = false;

            if (!determined) {
                if (hp1 > hp2) {
                    winner = true;
                } else if (hp1 < hp2) {
                    winner = false;
                } else {
                    even = true;
                }
            }

            if (even) {
                System.out.println("the result is even");
            } else {
                if (winner) {
                    System.out.println("player one is victorious");
                    Users.get(loginIndex1).coins += coin;
                    Users.get(loginIndex2).coins -= coin;
                } else {
                    System.out.println("player two is victorious");
                    Users.get(loginIndex1).coins -= coin;
                    Users.get(loginIndex2).coins += coin;
                }
            }
        } else {
            System.out.println("players dont have enough balance to play this mode");
        }
    }
}