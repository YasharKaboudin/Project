import java.util.ArrayList;
public class User {
    String Username;
    String Password;
    String Nickname;
    String Email;
    int PRQ = 0;
    String PRA;
    private ArrayList<Card> cards = new ArrayList<>();
    int score=0;
    int coins = 0;
    private int level = 1;
    User (String Username,String Password, String Nickname, String Email,String PRA,int PRQ,ArrayList<Card> cards)
    {
        this.Username=Username;
        this.Nickname=Nickname;
        this.Password=Password;
        this.Email=Email;
        this.PRA=PRA;
        this.PRQ=PRQ;
        this.cards=cards;
    }
    public void ask ()
    {
        if (this.PRQ==1)
            System.out.println("What is your father’s name ?");
        if (this.PRQ==2)
            System.out.println("What is your favourite color ?");
        if (this.PRQ==3)
            System.out.println("What was the name of your first pet?");
    }
    public ArrayList<Card> getCards() {
        return cards;
    }

    public boolean hasCard(Card card){
        for (Card card1 : this.cards){
            if(card.getName().equals(card1.getName())){
                return true;
            }
        }
        return false;
    }

    public ArrayList<Card> getBuyAble(ArrayList<Card> gameCards){
        ArrayList<Card> buyable = new ArrayList<>();
        for(Card card : gameCards){
            buyable.add(card);
        }
        for(int i = 0 ; i < buyable.size() ; i++){
            for(Card card : this.cards){
                if(buyable.get(i).getName().equals(card.getName())){
                    buyable.remove(i);
                }
            }
        }
        return buyable;
    }

    public ArrayList<Card> getUpgradeAble(){
        ArrayList<Card> upgradeAble = new ArrayList<>();
        for(Card card : this.cards){
            upgradeAble.add(card);
        }
        for(int i = 0 ; i < upgradeAble.size() ; i++){
            if(!upgradeAble.get(i).isUpgradeable()){
                upgradeAble.remove(i);
            }
        }
        return upgradeAble;
    }

    public int getCoins() {
        return coins;
    }
    public void setCoins(int coins) {
        this.coins = coins;
    }
    public int getLevel() {
        return level;
    }
    public void setCards (ArrayList<Card> cards)
    {
        this.cards=cards;
    }


}
