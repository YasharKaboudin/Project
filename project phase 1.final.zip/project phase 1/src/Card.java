public class Card{
    private int character;
    private String name = "";
    private int attack_defence;
    private int duration;
    private int player_damage;
    private int upgrade_level;
    private int upgrade_cost;
    private int level=1;
    private int buy_level=upgrade_level;
    private int price=upgrade_cost;
    boolean buyAble=true;

    Card(){

    }
    Card (String name,int attack_defence,int duration, int player_damage, int upgrade_level,int upgrade_cost,int character)
    {
        this.attack_defence=attack_defence;
        this.duration=duration;
        this.name=name;
        this.player_damage=player_damage;
        this.upgrade_cost=upgrade_cost;
        this.upgrade_level=upgrade_level;
        this.character=character;
    }
    public boolean IsSpecail(){
        if(this.name.equals("shield") || this.getName().equals("heal") || this.getName().equals("buff") || this.getName().equals("repair") || this.getName().equals("round_dec") || this.getName().equals("remover") || this.getName().equals("debuffer") || this.getName().equals("copy") || this.getName().equals("hider") || this.getName().equals("magnet")){
            return true;
        } else {
            return false;
        }
    }

    public int code (){
        if(this.getName().equals("shield")){
            return 0;
        } else if (this.getName().equals("heal")) {
            return 1;
        } else if (this.getName().equals("buff")) {
            return 2;
        } else if (this.getName().equals("repair")) {
            return 3;
        } else if (this.getName().equals("round_dec")) {
            return 4;
        } else if (this.getName().equals("remover")) {
            return 5;
        } else if (this.getName().equals("debuffer")) {
            return 6;
        } else if (this.getName().equals("copy")) {
            return 7;
        } else if (this.getName().equals("hider")) {
            return 8;
        } else if(this.getName().equals("magnet")) {
            return 9;
        } else {
            return -1;
        }
    }
    public boolean isUpgradeable(){
        if(this.name.equals("shield") || this.name.equals("repair") || this.name.equals("round_dec") || this.name.equals("remover") || this.name.equals("copy") || this.name.equals("hider") || this.name.equals("buff") || this.name.equals("debuffer") || this.name.equals("magnet")){
            return false;
        } else {
            return true;
        }
    }

    public int getUpgradePrice(){
        int upgradePrice = this.price;
        for(int i = 0 ; i < this.level ; i++){
            upgradePrice *= 1.25;
        }
        return upgradePrice;
    }

    public String getName() {
        return name;
    }

    public int getAttack_defence() {
        return (int)Math.ceil(this.attack_defence * Math.pow(1.2 , this.level));
    }

    public int getPlayer_damage() {
        return (int)Math.ceil(this.player_damage * Math.pow(1.2 , this.level));
    }

    public int getBuy_level() {
        return buy_level;
    }
    public int getUpgrade_level() {return upgrade_level;}
    public int getUpgrade_cost() {return upgrade_cost;}

    public int getDuration() {
        return duration;
    }

    public int getPrice() {
        return price;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }
    public void setAttack_defence(int attack_defence)
    {
        this.attack_defence=attack_defence;
    }

    public void setPlayer_damage(int player_damage) {
        this.player_damage = player_damage;
    }

    public int getCharNum ()
    {
        return this.character;
    }
    public boolean IsTableable(){
        if(this.getName().equals("buff") || this.getName().equals("repair") || this.getName().equals("round_dec") || this.getName().equals("remover") || this.getName().equals("debuffer") || this.getName().equals("copy") || this.getName().equals("hider") || this.getName().equals("magnet")){
            return false;
        } else {
            return true;
        }
    }
}
