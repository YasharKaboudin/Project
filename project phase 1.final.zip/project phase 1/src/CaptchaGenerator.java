import java.sql.*;
import java.util.ArrayList;

public class CaptchaGenerator {
    public static void main( String args[] ) {

        String s="ali yashar";
        String[] a=s.split("\\s+");
        System.out.println(a[0]);
        System.out.println(a[1]);
    }
}
