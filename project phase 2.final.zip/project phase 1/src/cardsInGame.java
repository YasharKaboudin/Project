public class cardsInGame{
    Card playeeCard = null;
    boolean disable = false;
    boolean filled = false;
    boolean broken = false;
    int copy = -1;

    public int isSuperior(cardsInGame card2){
        if(this.playeeCard == null && card2.playeeCard == null){
            return 0;
        } else if (this.playeeCard == null) {
            return -1;
        } else if (this.playeeCard == null) {
            return 1;
        } else {
            if(!this.playeeCard.IsSpecail() && !card2.playeeCard.IsSpecail()) {
                if (this.playeeCard.getAttack_defence() > card2.playeeCard.getAttack_defence()) {
                    return 1;
                } else if (this.playeeCard.getAttack_defence() < card2.playeeCard.getAttack_defence()) {
                    return -1;
                } else {
                    return 0;
                }
            } else {
                if(this.playeeCard.getName().equals("shield")){
                    return 1;
                }
                if(card2.playeeCard.getName().equals("shield")){
                    return -1;
                }
                if(this.playeeCard.getName().equals("heal")){
                    return -1;
                }
                if(card2.playeeCard.getName().equals("heal")){
                    return 1;
                }
            }
        }
        return 0;
    }

}
